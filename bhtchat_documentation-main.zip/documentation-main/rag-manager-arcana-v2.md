# RAG Manager (eigener Service) + Arcana v2 Integration – Anforderungen & Umsetzungsplan

## Ausgangslage (Ist-Zustand im Repo)

- **Dokumentenverarbeitung existiert bereits** und ist ein gutes Muster für “Ingestion → Hintergrundprozess → Session-Metadaten → UI-Attachments”:
  - Upload/Processing: `chat/views.py` (`upload_document`, `process_document`)
  - Docling-Konvertierung: `POST /v1/documents/convert` (AcademicCloud)
  - Attachments/Session-Metadaten: `templates/partials/document_modal.html`, `chat/urls.py` (`document/*`, `session/save-document-metadata`)
- **Legacy-Arcana ist nicht mehr gewünscht**:
  - Kein Support mehr für “remote Arcana”/`-rag` Modelle.
  - Arcana bedeutet ab jetzt ausschließlich **lokale Wissenspakete** (siehe `arcana_manager`).

## Zielbild (Soll-Zustand)

Ihr baut ein **eigenständiges RAG-Index-System** (“Arcana Manager”) als eigene Oberfläche unter einer eigenen Subdomain, das:

- **Dokumente/Dateien pro Formation/Domäne** (Multi-Tenancy) verwaltet
- **Indexing (Embeddings + Vektordatenbank)** robust, skalierbar und auditierbar ausführt
- der Chat-App einen stabilen **“Index-Identifier/Access-Link”** anbietet (vergleichbar Arcana-ID/Access-Link)
- **keine** externe Arcana-Abhängigkeit benötigt (nur Docling + Embeddings API als Bausteine).

## Begriffe (Vokabular)

- **Formation / Domäne**: Mandanten-/Wissensraum (z.B. “Informatik”, “Kanzlei X”, “BGB”).
- **Index / Corpus / Knowledge Base (KB)**: ein durchsuchbarer Wissensraum innerhalb einer Formation.
- **Access-Link / Index-ID**: stabile Referenz, die die Chat-App speichert und bei Chat-Requests mitsendet.
- **Ingestion**: Upload → Extraktion → Chunking → Embeddings → Persistenz → (Re-)Index.
- **Retrieval**: Query → Query-Embedding → Similarity Search (+Filter) → Kontext → LLM.

## Kernanforderungen (für 100–200 Nutzer)

### Funktionale Anforderungen

- **Wissenspakete (Arcana Packages)**
  - Paket anlegen/löschen (admin-only)
  - Dateien hochladen (zunächst manuell; alle Formate, die Docling versteht)
  - Paket kann fortlaufend erweitert werden (neue Dateien in bestehendes Paket)
  - Indexing/Re-Indexing (Docling → Chunking → Embeddings → pgvector Upsert)
  - Status pro Datei: “pending / converted / indexed / error” inkl. Fehlerdetails
- **Retrieval API**
  - Query + Filter (KB, Document-ID, Zeit, Tags, Formation)
  - Rückgabe: Top-K Chunks + Metadaten + Quellen (für Zitate/Transparenz)
- **Chat-Integration (Mehrfachauswahl)**
  - Nutzer sehen ihre zugewiesenen Wissenspakete in der Sidebar und können **mehrere** aktivieren.
  - Auswahl wird pro Chat-Session gespeichert (analog Dokument-Attachments).
  - Bei jeder Anfrage wird dynamisch Retrieval über die aktiven Pakete gemacht und als Kontext injected.

### Nicht-funktionale Anforderungen

- **Multi-Tenancy & Berechtigungen**
  - Isolation zwischen Formationen (Daten & Suche)
  - Rollen: Admin (KB verwalten), Editor (Dokumente), Reader (nur nutzen)
  - “Index/Access-Link” muss **nicht erratbar** sein (UUID/opaque token)
- **Performance**
  - Retrieval: typ. < 200–500ms (ohne LLM), mit Filter/Hybrid ggf. höher
  - Embedding-Ingestion: asynchron, batch-fähig, restart-safe
  - Gleichzeitigkeit: realistisch 10–40 parallele Interaktionen (Spitzen) bei 100–200 Nutzern
- **Reliability**
  - idempotente Jobs (keine Doppel-Embeddings)
  - Backpressure/Queues für große Upload-Wellen
  - Re-tries mit Exponential Backoff bei API-Limits/Timeouts
- **Security**
  - TLS (Subdomain), HSTS, minimaler öffentlich erreichbarer Angriffspunkt
  - AuthN: JWT/OAuth2 oder Service-to-Service Token + Benutzer-Scope
  - AuthZ: “user → formation → index”
  - Secrets: API Keys (AcademicCloud) im Secret-Store, niemals in DB unverschlüsselt
  - Audit Log: wer hat welche KB/Dokumente geändert, und wann
- **Observability**
  - Metriken: Ingestion Throughput, Queue Depth, Retrieval Latency, Error Rates, Token/Request Zähler
  - Tracing: Request-IDs end-to-end (Chat → RAG Manager → Embeddings/VectorDB)
  - Logs: strukturiert, PII/Content-Schutz (Redaction)

## Datenfluss-Architektur

### Ingestion (Datei → Index)

1. Upload (RAG Manager API, oder UI des RAG Managers)
2. Konvertierung/Extraktion (z.B. Docling-API wie in der App)
3. Chunking (Parameter pro KB, z.B. 800–1500 chars, overlap 10–20%)
4. Embeddings (AcademicCloud `/v1/embeddings`, OpenAI-kompatibel)
5. Persistenz der Vektoren + Metadaten (Vektor-DB)
6. Index “ready”

Wichtig: Schritt 2–5 laufen **asynchron** in Worker-Jobs; API liefert sofort `job_id`/Status.

### Retrieval (Query → Kontext)

1. Query-Embedding (gleiches Modell wie Index; pro KB fest verdrahtet oder versioniert)
2. Similarity Search + Filter (KB/Formation/Tags)
3. Kontext-Building (z.B. Top 6–12 Chunks, Dedup, Max-Token Budget)
4. Rückgabe an Chat-App oder direktes “Chat-with-RAG” im RAG Manager

## Vektor-Datenbank: Optionen & Empfehlung

### Auswahlkriterien (praxisnah)

- **Filter-Fähigkeit** (tenant_id, kb_id, doc_id, tags)
- **HNSW/ANN Performance** bei wachsenden Indizes
- **Backups/Snapshots** und Wiederherstellbarkeit
- **Betrieb** (1 Container vs mehrere, Wartung, Upgrades)
- **Hybrid Search** (optional: BM25 + Vector)

### Optionen

- **Postgres + pgvector**
  - Pro: sehr robust, bekannt, starke Filter/SQL, Backups einfach, “one stack”
  - Contra: ANN/Performance kann bei sehr großen Indizes komplexer werden (Tuning/Partitioning)
  - Passt gut, wenn ihr ohnehin Postgres “sauber” betreibt und die Indexgröße moderat bleibt.
- **Qdrant**
  - Pro: dedizierte VectorDB, gute Filter, schnelle ANN, einfache Docker-Deployments, Snapshots
  - Contra: zusätzliche Komponente, anderes Ops-Tooling
  - Sehr guter Sweet Spot für “100–200 Nutzer” + saubere Multi-Tenant Filter.
- **Weaviate / Milvus**
  - Pro: sehr leistungsfähig, viele Features
  - Contra: mehr Ops-Komplexität (v.a. Milvus), oft “overkill” für eure Größe.

### Empfehlung (für euren beschriebenen Scope)

- **Empfohlen: Qdrant als VectorDB** + optional eine kleine relationale DB für Metadaten (oder Metadaten direkt in Qdrant Payload).
- Alternative: **Postgres + pgvector** als bewusst simpler Stack, wenn ihr “nur” einige 10k–einige Mio Chunks erwartet und SQL-first arbeiten wollt.

## Embeddings (AcademicCloud)

Embeddings laufen API-kompatibel zu OpenAI:

- Endpoint: `/v1/embeddings`
- Model-Beispiel: `e5-mistral-7b-instruct`
- Output: Vektor-Listen im OpenAI-Format

Wichtig für Betrieb:

- **Batching** (inputs als Liste) ist essenziell für Durchsatz/Kosten.
- **Rate Limits/Timeouts** einplanen → Queue + Retry.
- **Model-Versionierung**: KB speichert `embedding_model` + ggf. `embedding_dimension`.

## Externe Arcana v2 API

Aktuell **nicht Teil des Scopes**, da ihr ausschließlich lokal indexieren und innerhalb der Applikation nutzen wollt.

## Subdomain / Deployment

### Deployment-Skizze

- `rag-manager` (API + UI optional)
- `vector-db` (Qdrant oder Postgres/pgvector)
- `worker` (Celery/RQ/Arq) + `redis` (Queue) – optional aber empfohlen
- `object storage` (S3/MinIO) – optional, wenn Uploads nicht im App-Volume liegen sollen
- Reverse Proxy (nginx/traefik/caddy) für TLS + Subdomain Routing:
  - `chatbht.com` → bestehende Chat-App
  - `arcana.chatbht.com` → Arcana Manager UI (admin-only)

### Öffentliche APIs (minimal)

- **Index**
  - `POST /v1/indexes` (create)
  - `GET /v1/indexes` (list for user/tenant)
  - `GET /v1/indexes/{id}` (status)
  - `DELETE /v1/indexes/{id}` (deactivate)
- **Documents**
  - `POST /v1/indexes/{id}/documents` (upload/attach)
  - `GET /v1/indexes/{id}/documents` (list)
  - `DELETE /v1/indexes/{id}/documents/{doc_id}`
- **Jobs**
  - `GET /v1/jobs/{job_id}`
- **Search / Retrieve**
  - `POST /v1/indexes/{id}/search` → `[{chunk, score, metadata, citations}]`

Optional:
- `POST /v1/chat/completions` (RAG Manager macht Retrieval + ruft LLM), dann ist die Chat-App noch dünner.

## Integrationsplan in der bestehenden App (Gangwai)

### 1) Legacy-Arcana restlos entfernen (kurzfristig)

- Entfernen aller remote-Arcana Endpoints/Modelle/Templates.
- Arcana bedeutet in der UI nur noch: **Wissenspakete (ArcanaPackage)**.

### 2) Arcana Manager Integration (mittelfristig)

UI/UX analog “Dokumente verarbeiten”:

- Sidebar “Wissenspakete” (Mehrfachauswahl)
  - Pakete aus DB (nur zugewiesene)
  - Auswahl wird in `ChatSession.metadata` gespeichert
- beim Senden einer Nachricht:
  - Session enthält `selected_index_ids` (eine oder mehrere)
  - Backend baut Chat-Request:
    - entweder: fragt RAG Manager nach Retrieval-Kontext und hängt ihn an `messages`
    - oder: ruft RAG Manager “chat completion” direkt auf (falls ihr das so baut)

### 3) Rollen/Access (langfristig)

- Arcana Manager ist **nicht** für alle Nutzer offen:
  - Nur wenige “Indexer/Admins” (Django `is_staff`/`is_superuser` oder separate Gruppe).
  - Admin-User aus der Hauptapp ist dort automatisch Admin.
  - Zuweisung von Paketen an Nutzer erfolgt im Django Admin (`ArcanaPackage.users`).

## Offene Fragen (bitte beantworten, bevor wir final implementieren)

### Produkt/UX

- Soll ein Nutzer **mehrere** Indizes gleichzeitig auswählen können (Hybrid/Union)?
- Brauchen wir **Zitate** im UI (Quellenbox) als Pflicht?
- Wie werden “Formationen” modelliert: feste Gruppen, Django-Gruppen, eigene Tabelle?

### Daten/Größe

- Erwartete Indexgröße pro Formation (Dokumentanzahl, Gesamt-MB)?
- Update-Frequenz: wie oft kommen neue Dokumente rein?
- Muss es “Near real-time” sein (Sekunden/Minuten) oder reicht “Batch overnight”?

### Betrieb/Security

- Auth: soll der RAG Manager die gleiche Auth (Session/JWT) wie die Chat-App nutzen?
- Datenresidenz/Compliance: besondere Vorgaben (z.B. DSGVO/Logs)?
- Backups: RPO/RTO Zielwerte?

### LLM-Flow

- Soll der RAG Manager nur Retrieval liefern (Context-Provider) oder auch die LLM-Anfrage machen?
- Welche LLM-Modelle sollen für Arcana v2 genutzt werden (z.B. `qwen3-30b-a3b-instruct-2507`)?

## Nächste Schritte (konkret)

1. **Arcana Manager Routing**:
   - `arcana.chatbht.com` via nginx auf `/arcana-manager/` mappen (TLS via certbot).
2. **Arcana Manager UX polish**:
   - “Access Link”/UUID anzeigen + Copy Button
   - File Actions (Download/Delete) wie im Screenshot
3. **Chat Multi-Select + Retrieval**:
   - Auswahlchips anzeigen
   - Retrieval pro Paket und Kontext-Injection stabilisieren (Quellen/Zitate optional)
4. **RAG Manager Architektur festnageln**:
   - Qdrant vs pgvector Entscheidung
   - AuthN/AuthZ Modell (Tenant/Formation)
5. (Später) **Auto-Indexer/Webscraping**:
   - Design vorbereiten, aber Feature erst nach manuellem Upload stabilisieren

