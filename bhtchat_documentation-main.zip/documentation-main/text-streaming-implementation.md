# Text-Streaming-Implementierung - Umfassender Leitfaden

## Übersicht

Diese Dokumentation beschreibt detailliert, wie Text-Streaming in der gesamten Anwendung implementiert ist. Die App verwendet **Server-Sent Events (SSE)** für das Echtzeit-Streaming von AI-Antworten und rendert den Text live im Browser mit client-seitigem Markdown-Rendering.

---

## Technologien und Architektur

### Backend-Technologien
- **Django StreamingHttpResponse**: Für SSE-Streams
- **Python Generators**: Für effizientes Streaming von Token-Chunks
- **OpenAI API / Academic Cloud API**: Externe AI-APIs mit Streaming-Support
- **JSON**: Datenformat für SSE-Nachrichten (`data: {json}\n\n`)

### Frontend-Technologien
- **EventSource API**: Native Browser-API für SSE-Verbindungen
- **Client-seitiges Markdown-Rendering**: `renderMarkdownLive()` Funktion
- **KaTeX**: Für LaTeX/Math-Rendering
- **Highlight.js**: Für Syntax-Highlighting in Code-Blöcken
- **Alpine.js**: Für reaktive UI-Komponenten (Markdown/Plaintext Toggle)
- **HTMX**: Für dynamisches Laden von Nachrichten

### Datenfluss
```
AI API → Django Backend (Generator) → SSE Stream → EventSource (Browser) → Live Rendering → DOM Update
```

---

## 1. Normale Chat-Ansicht

### Backend-Implementierung

**Datei**: `chat/views.py` - `generate_response_stream()`

```python
@login_required
def generate_response_stream(request, msg_id):
    # Erstellt einen SSE-Stream
    def generate_stream():
        for chunk in upstream:  # Von OpenAI API
            if "content" in chunk:
                full_response += chunk["content"]
                # Sendet jeden Token sofort
                yield f"data: {json.dumps({'content': chunk['content']})}\n\n"
            elif "finish_reason" in chunk:
                yield f"data: {json.dumps({'finish_reason': chunk['finish_reason']})}\n\n"
        
        # Speichert vollständige Antwort in Datenbank
        assistant_msg = ChatMessage.objects.create(
            session=session,
            role="assistant",
            content=full_response
        )
    
    return StreamingHttpResponse(generate_stream(), content_type='text/event-stream')
```

**Wichtige Punkte**:
- Jeder Token wird sofort als JSON-Objekt gesendet: `{"content": "token"}`
- `finish_reason` signalisiert Stream-Ende
- Vollständige Antwort wird nach Stream-Ende in Datenbank gespeichert

### Frontend-Implementierung

**Datei**: `templates/partials/send_prompt_response_streaming.html`

**Streaming-Logik**:
```javascript
const eventSource = new EventSource(streamUrl);

eventSource.onmessage = function(event) {
    const data = JSON.parse(event.data);
    
    if (data.content) {
        fullContent += data.content;
        // Speichert Inhalt global für Toggle-Funktionalität
        window.messageContents[messageId] = fullContent;
        
        // Live-Rendering mit updateContentLive()
        window.updateContentLive(fullContent, messageContainer);
    }
    
    if (data.finish_reason) {
        eventSource.close();
        finalizeMessage();  // Finalisiert Nachricht
    }
};
```

**Live-Rendering** (`static/js/main.js`):
```javascript
window.updateContentLive = function(fullText, messageElement) {
    const isMarkdownView = messageElement.__x?.$data?.isMarkdownView !== false;
    
    if (isMarkdownView) {
        // Rendert Markdown live
        contentElement.innerHTML = window.renderMarkdownLive(fullText);
        
        // Syntax-Highlighting sofort anwenden
        window.applySyntaxHighlighting(contentElement);
        
        // LaTeX in Echtzeit rendern
        window.renderMathInElement(messageElement, {...});
    } else {
        // Plaintext-Ansicht
        contentElement.textContent = fullText;
    }
};
```

**Markdown-Rendering** (`static/js/markdown_renderer.js`):
- `renderMarkdownLive()`: Konvertiert Markdown zu HTML
- Schützt Code-Blöcke, LaTeX und Reasoning-Blöcke während der Transformation
- Wendet Inline-Formatierungen (Bold, Italic, Links) an
- Konvertiert Tabellen, Listen und Überschriften

---

## 2. Shared Chat

### Unterschiede zur normalen Chat-Ansicht

**Backend**: `chat/views.py` - `generate_shared_response_stream()`
- Identische Implementierung wie normale Chat-Ansicht
- Verwendet `share_uuid` statt `session` für Authentifizierung

**Frontend**: `templates/partials/shared_send_prompt_response_streaming.html`
- Verwendet `window.sharedMessageContents` statt `window.messageContents`
- Identische Streaming-Logik
- Gleiche Live-Rendering-Funktion (`updateContentLive`)

**Wichtiger Unterschied**:
- Shared Chats speichern Inhalte in separatem globalen Objekt
- Ermöglicht gleichzeitiges Streaming in mehreren Shared-Chat-Instanzen

---

## 3. Arcana-Funktion

### Backend-Implementierung

**Datei**: `chat/views.py` - `generate_arcana_response_stream()`

```python
def generate_stream():
    for chunk in send_arcana_message_stream(
        model="meta-llama-3.1-8b-rag",
        messages=history,
        arcana={"id": arcana.arcana_id, "key": arcana.arcana_key},
        ...
    ):
        if "content" in chunk:
            full_response += chunk["content"]
            yield f"data: {json.dumps({'content': chunk['content']})}\n\n"
```

**Besonderheiten**:
- Verwendet spezielle Arcana-API (`chat/api.py` - `send_arcana_message_stream()`)
- Arcana-spezifische Parameter werden übergeben
- Gleiche SSE-Struktur wie normale Chat-Ansicht

### Frontend-Implementierung

**Datei**: `templates/partials/arcana_send_prompt_response_streaming.html`

- Identische EventSource-Logik
- Verwendet `window.messageContents` (wie normale Chat-Ansicht)
- Gleiche Live-Rendering-Pipeline

**Hinweis**: Arcana verwendet jetzt client-seitiges Rendering (wie Standard & Shared), nicht mehr server-seitig.

---

## 4. Bild-Streaming (Vision)

### Backend-Implementierung

**Datei**: `chat/views.py` - `generate_vision_response_stream()`

```python
def stream():
    vision_request = {
        "model": vision_upload.model_used,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": user_msg.content},
                {"type": "image_url", "image_url": {"url": vision_upload.base64_data}}
            ]
        }],
        "stream": True
    }
    
    response = requests.post(API_URL, json=vision_request, stream=True)
    
    for line in response.iter_lines():
        json_data = json.loads(data)
        if 'content' in delta:
            content = delta['content']
            full_content += content
            yield f"data: {{\"content\": {json.dumps(content)} }}\n\n"
    
    # Speichert vollständige Antwort
    assistant_msg.content = full_content
    assistant_msg.save()
```

**Besonderheiten**:
- Sendet Bild als Base64-encoded `data:image/...;base64,` URL
- Verwendet Vision-Modelle (z.B. GPT-4 Vision)
- Gleiche SSE-Struktur

### Frontend-Implementierung

**Datei**: `templates/partials/message_vision_streaming.html`

**Aktueller Stand**: Vision-Streaming verwendet **noch nicht** die einheitliche `updateContentLive()` Funktion!

**Problem**: Vision-Streaming rendert aktuell nur Plaintext während des Streams:
```javascript
// In chat_window.html (Zeile ~1234)
contentElement.textContent += data.content;  // Nur Plaintext!
```

**Nach Stream-Ende**: Wird Markdown server-seitig gerendert:
```javascript
fetch('/chat/render-markdown/', {
    method: 'POST',
    body: `content=${encodeURIComponent(contentElement.textContent)}`
})
.then(data => {
    contentElement.innerHTML = data.html;  // Server-seitiges Rendering
});
```

**Verbesserungspotential**: Vision sollte `updateContentLive()` verwenden für konsistentes Live-Rendering.

---

## 5. Dokument-Verarbeitung

### Backend-Implementierung

**Datei**: `chat/views.py` - `generate_document_response_stream()`

```python
def stream():
    document_request = {
        "model": model_api_id,
        "messages": [
            {
                "role": "system",
                "content": system_prompt  # Enthält Dokument-Inhalte
            },
            {"role": "user", "content": user_msg.content}
        ],
        "stream": True
    }
    
    # Identische Streaming-Logik wie Vision
    for line in response.iter_lines():
        if 'content' in delta:
            full_content += content
            yield f"data: {json.dumps({'content': content})}\n\n"
    
    assistant_msg.content = full_content
    assistant_msg.save()
```

**Besonderheiten**:
- Dokumente werden in System-Prompt eingebettet
- Kann mehrere Dokumente gleichzeitig verarbeiten
- Gleiche SSE-Struktur

### Frontend-Implementierung

**Datei**: `templates/partials/chat_window.html` (Zeile ~1220)

**Aktueller Stand**: Dokument-Streaming verwendet **noch nicht** die einheitliche `updateContentLive()` Funktion!

**Problem**: Wie bei Vision - nur Plaintext während des Streams:
```javascript
contentElement.textContent += data.content;  // Nur Plaintext!
```

**Nach Stream-Ende**: Server-seitiges Markdown-Rendering:
```javascript
fetch('/chat/render-markdown/', {
    method: 'POST',
    body: `content=${encodeURIComponent(contentElement.textContent)}`
})
.then(data => {
    contentElement.innerHTML = data.html;
});
```

**Verbesserungspotential**: Dokumente sollten `updateContentLive()` verwenden für konsistentes Live-Rendering.

---

## 6. Rohtext-Button (Markdown/Plaintext Toggle)

### Implementierung

**Alpine.js State Management**:
```html
<div x-data="{ 
    isMarkdownView: true,
    toggleView() {
        this.isMarkdownView = !this.isMarkdownView;
        window.toggleMessageView(messageId, this.isMarkdownView);
    }
}">
```

**Toggle-Funktion** (`static/js/main.js`):

**Für laufende Streams** (`toggleMessageView`):
```javascript
window.toggleMessageView = function(messageId, isMarkdownView) {
    const fullContent = window.messageContents[messageId];
    
    if (isMarkdownView) {
        // Wechselt zu Markdown-Ansicht
        contentElement.innerHTML = window.renderMarkdownLive(fullContent);
        window.applySyntaxHighlighting(contentElement);
        window.renderMathInElement(messageContainer, {...});
    } else {
        // Wechselt zu Plaintext-Ansicht
        contentElement.innerHTML = `<div class="whitespace-pre-wrap font-mono">${fullContent}</div>`;
    }
};
```

**Für bereits gerenderte Nachrichten** (`toggleExistingMessageView`):
```javascript
window.toggleExistingMessageView = function(messageId, isMarkdownView) {
    const originalContent = element.getAttribute('data-original-content');
    
    if (isMarkdownView) {
        // Server-seitiges Rendering für gespeicherte Nachrichten
        fetch('/chat/render-markdown/', {
            method: 'POST',
            body: `content=${encodeURIComponent(originalContent)}`
        })
        .then(data => {
            contentElement.innerHTML = data.html;
            // LaTeX und Syntax-Highlighting anwenden
        });
    } else {
        // Plaintext-Ansicht
        contentElement.textContent = originalContent;
    }
};
```

**Wichtige Unterschiede**:
- **Während Streaming**: Verwendet `window.messageContents` (aktueller Stream-Inhalt)
- **Nach Streaming**: Verwendet `data-original-content` Attribut (gespeicherter Inhalt)
- **Markdown-Rendering**: Client-seitig für Streams, server-seitig für gespeicherte Nachrichten

---

## 7. Seiten-Neuladen (Page Reload)

### Rendering-Prozess

**1. Initiales Laden** (`static/js/main.js` - `renderSavedMessages()`):

```javascript
window.renderSavedMessages = function() {
    const messageElements = document.querySelectorAll('[id^="message-content-"]');
    
    messageElements.forEach((element) => {
        const originalContent = element.getAttribute('data-original-content');
        
        // Dekodiert HTML-Entities
        const decodedContent = originalContent
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&amp;/g, '&')
            // ...
        
        // Speichert für Toggle-Funktionalität
        window.messageContents[messageId] = decodedContent;
        
        // Rendert Markdown client-seitig
        element.innerHTML = window.renderMarkdownLive(decodedContent);
        
        // Syntax-Highlighting anwenden
        window.applySyntaxHighlighting(element);
        
        // LaTeX rendern
        window.renderMathInElement(messageContainer, {...});
    });
};
```

**2. DOMContentLoaded Event**:
```javascript
document.addEventListener('DOMContentLoaded', () => {
    window.renderSavedMessages();  // Rendert alle gespeicherten Nachrichten
    
    // LaTeX in allen .prose Elementen rendern
    document.querySelectorAll('.prose').forEach(element => {
        window.renderMathInElement(element, {...});
    });
});
```

**3. HTMX After-Swap Event**:
```javascript
document.body.addEventListener('htmx:afterSwap', (e) => {
    // Rendert neue Nachrichten nach HTMX-Swap
    if (window.renderSavedMessages) {
        window.renderSavedMessages();
    }
});
```

**Wichtige Punkte**:
- Gespeicherte Nachrichten werden **client-seitig** gerendert (konsistent mit Live-Rendering)
- Original-Markdown wird in `data-original-content` Attribut gespeichert
- HTML-Entities werden dekodiert vor Rendering
- LaTeX und Syntax-Highlighting werden nach Rendering angewendet

---

## 8. Datenpersistierung

### Backend-Speicherung

**Nach Stream-Ende**:
```python
# In generate_response_stream()
assistant_msg = ChatMessage.objects.create(
    session=session,
    role="assistant",
    content=full_response  # Vollständiger Markdown-Text
)
```

**Wichtige Punkte**:
- Nur **Rohtext (Markdown)** wird in Datenbank gespeichert
- Kein HTML wird gespeichert
- Ermöglicht späteres Re-Rendering mit verschiedenen Stilen

### Frontend-Speicherung

**Während Streaming**:
```javascript
window.messageContents[messageId] = fullContent;  // Globaler Speicher
```

**Nach Streaming**:
```javascript
messageContentElement.setAttribute('data-original-content', fullContent);
```

**Nach Seiten-Neuladen**:
- Original-Markdown wird aus `data-original-content` Attribut gelesen
- Wird client-seitig zu HTML gerendert

---

## 9. Verbesserungspotential

### 🔴 Kritische Verbesserungen

#### 1. **Vision-Streaming: Live Markdown-Rendering**
**Problem**: Vision rendert nur Plaintext während des Streams, Markdown erst nach Stream-Ende.

**Lösung**: Vision sollte `updateContentLive()` verwenden:
```javascript
// Statt:
contentElement.textContent += data.content;

// Sollte sein:
fullContent += data.content;
window.updateContentLive(fullContent, messageContainer);
```

**Datei**: `templates/partials/chat_window.html` (Zeile ~1220-1240)

#### 2. **Dokument-Streaming: Live Markdown-Rendering**
**Problem**: Dokumente rendern nur Plaintext während des Streams.

**Lösung**: Dokumente sollten `updateContentLive()` verwenden:
```javascript
// Statt:
contentElement.textContent += data.content;

// Sollte sein:
fullContent += data.content;
window.updateContentLive(fullContent, messageContainer);
```

**Datei**: `templates/partials/chat_window.html` (Zeile ~1220-1240)

### 🟡 Wichtige Verbesserungen

#### 3. **Einheitliche Streaming-Implementierung**
**Problem**: Verschiedene Streaming-Implementierungen für verschiedene Features.

**Lösung**: 
- Erstelle eine zentrale `StreamingManager` Klasse
- Alle Features verwenden dieselbe Basis-Implementierung
- Reduziert Code-Duplikation

#### 4. **Fehlerbehandlung verbessern**
**Problem**: Fehlerbehandlung ist inkonsistent zwischen verschiedenen Streaming-Typen.

**Lösung**:
- Einheitliche Fehlerbehandlung
- Retry-Mechanismus bei Verbindungsabbrüchen
- Bessere Fehlermeldungen für Benutzer

#### 5. **Performance-Optimierung**
**Problem**: LaTeX-Rendering wird bei jedem Token-Update ausgeführt.

**Lösung**:
- Debouncing für LaTeX-Rendering (nur alle 500ms)
- Incrementales Rendering für große Nachrichten
- Virtual Scrolling für sehr lange Antworten

#### 6. **Code-Highlighting während Streaming**
**Problem**: Code-Blöcke werden erst nach Abschluss hervorgehoben.

**Lösung**:
- Incrementales Syntax-Highlighting während Streaming
- Erkenne Code-Blöcke frühzeitig (auch wenn unvollständig)
- Highlighting für unvollständige Blöcke mit Placeholder

### 🟢 Nice-to-Have Verbesserungen

#### 7. **Streaming-Status-Indikatoren**
- Zeige Streaming-Geschwindigkeit (Tokens/Sekunde)
- Zeige geschätzte verbleibende Zeit
- Zeige Token-Anzahl während Streaming

#### 8. **Streaming-Pause/Resume**
- Möglichkeit, Streaming zu pausieren
- Möglichkeit, Stream fortzusetzen
- Speichern von Zwischenständen

#### 9. **Mehrere gleichzeitige Streams**
- Unterstützung für mehrere gleichzeitige Streams
- Unabhängige Stream-Verwaltung
- Bessere Ressourcen-Verwaltung

#### 10. **Offline-Support**
- Service Worker für Offline-Funktionalität
- Queue für gescheiterte Streams
- Automatisches Retry bei Verbindungswiederherstellung

---

## 10. Technische Details

### SSE-Format

**Standard-Format**:
```
data: {"content": "token"}\n\n
data: {"content": " "}\n\n
data: {"finish_reason": "stop"}\n\n
```

**Fehler-Format**:
```
data: {"error": "Fehlermeldung"}\n\n
```

**Stream-Ende**:
```
data: [DONE]\n\n
```

### Markdown-Rendering-Pipeline

1. **HTML-Escaping**: Verhindert XSS-Angriffe
2. **Code-Block-Extraktion**: Schützt Code-Blöcke vor Markdown-Transformation
3. **LaTeX-Extraktion**: Schützt LaTeX-Ausdrücke
4. **Reasoning-Block-Extraktion**: Schützt `<think>` Tags
5. **Markdown-Transformation**: Konvertiert Markdown zu HTML
6. **Block-Wiederherstellung**: Fügt geschützte Blöcke wieder ein
7. **Syntax-Highlighting**: Highlight.js für Code-Blöcke
8. **LaTeX-Rendering**: KaTeX für mathematische Ausdrücke

### Globale Variablen

```javascript
window.messageContents = {};           // Normale Chat-Nachrichten
window.sharedMessageContents = {};     // Shared Chat-Nachrichten
window.updateContentLive = function(); // Live-Rendering-Funktion
window.renderMarkdownLive = function(); // Markdown-Renderer
window.toggleMessageView = function();  // Toggle für laufende Streams
window.toggleExistingMessageView = function(); // Toggle für gespeicherte Nachrichten
```

---

## 11. Zusammenfassung

### Aktuelle Implementierung

✅ **Funktioniert gut**:
- Normale Chat-Ansicht: Vollständiges Live-Rendering
- Shared Chat: Vollständiges Live-Rendering
- Arcana: Vollständiges Live-Rendering
- Markdown/Plaintext Toggle: Funktioniert für alle Ansichten
- Seiten-Neuladen: Client-seitiges Rendering funktioniert

⚠️ **Verbesserungsbedarf**:
- Vision-Streaming: Nur Plaintext während Streaming
- Dokument-Streaming: Nur Plaintext während Streaming
- Inkonsistente Implementierungen zwischen Features

### Empfohlene Prioritäten

1. **Hoch**: Vision- und Dokument-Streaming auf Live-Rendering umstellen
2. **Mittel**: Einheitliche Streaming-Implementierung
3. **Niedrig**: Performance-Optimierungen und Nice-to-Have Features

---

## 12. Code-Referenzen

### Backend
- `chat/views.py`: `generate_response_stream()` (Zeile 1673)
- `chat/views.py`: `generate_shared_response_stream()` (Zeile 3460)
- `chat/views.py`: `generate_arcana_response_stream()` (Zeile 1871)
- `chat/views.py`: `generate_vision_response_stream()` (Zeile 2214)
- `chat/views.py`: `generate_document_response_stream()` (Zeile 2024)
- `chat/api.py`: `send_message_stream()` (Zeile 55)
- `chat/api.py`: `send_arcana_message_stream()` (Zeile 131)

### Frontend
- `templates/partials/send_prompt_response_streaming.html`: Normale Chat-Streaming
- `templates/partials/shared_send_prompt_response_streaming.html`: Shared Chat-Streaming
- `templates/partials/arcana_send_prompt_response_streaming.html`: Arcana-Streaming
- `templates/partials/message_vision_streaming.html`: Vision-Template
- `templates/partials/message_document_streaming.html`: Dokument-Template
- `templates/partials/chat_window.html`: Dokument-Streaming-Logik (Zeile ~1200)
- `static/js/main.js`: `updateContentLive()`, `renderSavedMessages()` (Zeile 174, 108)
- `static/js/markdown_renderer.js`: `renderMarkdownLive()` (Zeile 332)

---

**Erstellt**: 2024
**Version**: 1.0
**Status**: Umfassende Dokumentation der aktuellen Implementierung




