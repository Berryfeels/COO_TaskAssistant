# Agentensystem (Planner · Tools · Sandbox · Worktree) – Architektur & Funktionsweise

Diese Datei dokumentiert **das Agentensystem in Gangwai** so, wie es aktuell implementiert ist (Stand: Code im Repo), inklusive UI-Features, Tool-Calls, Datenflüssen und den wichtigsten Guardrails/Trade-offs.

Sie ergänzt:

- `docs/guides/agent-mode.md` (Nutzer-/Feature-Überblick)
- `docs/mcp-server-architecture.md` (Details zu MCP + Python Sandbox)
- `docs/text-streaming-implementation.md` (SSE/Streaming/Renderer)

---

## Ziele des Agentensystems

Im „Agenten-Modus“ soll der Chat nicht nur Text generieren, sondern **Werkzeuge planen und ausführen**, z.B.:

- Web-Recherche (`web.search`, `web.fetch`, Downloads)
- Dateisystemzugriff im Worktree (`fs.list/read/write`)
- Python-Ausführung (Plots, Tabellen, Exporte) in einer isolierten Sandbox (`python.execute`)
- KB-Workflows (Docling/Embeddings/Retrieve)

Wichtig sind dabei:

- **Transparenz**: Live-Logs + Tool-Karten im UI
- **Sicherheit**: Sandbox, URL-Sanitizing, keine Base64-Bilder, keine Remote-Image-Leaks
- **Reproduzierbarkeit**: Artefakte und Dateien landen im Worktree und sind per Link abrufbar
- **Share-Safety**: Artefakt-Links funktionieren auch in Shared Chats (über share-spezifische Endpunkte)

---

## Komponenten (High-Level)

```mermaid
flowchart LR
  UI[Browser UI\nHTMX + Alpine + EventSource] -->|POST /chat/prompt/| Django[Django: chat/views.py]
  Django -->|SSE /chat/agent/response/stream/:msg_id| UI

  Django -->|HTTP JSON| MCP[MCP Server :9000\nTools: web.*, fs.*, doc.*, kb.*]
  Django -->|HTTP JSON| Py[Python Sandbox :9100\n/tools/python/execute]

  Django -->|HTTP| Gateway[AcademicCloud Gateway\n/v1/chat/completions]
  MCP -->|HTTP| Gateway
```

---

## Datenmodell & Persistenz

### `ChatSession` (pro Chat)

- **Primärer Scope** für Agent-Settings und Worktree
- Relevante Metadata Keys:
  - `metadata["arcana_packages"]`: Liste der ausgewählten Wissensspeicher-Pakete
  - `metadata["agent"]`:
    - `agent_enabled: bool`
    - `tools: {tool_key: bool}` Allowlist pro Tool

### `ChatMessage` (pro Nachricht)

Nach Abschluss eines Agent-Runs wird eine Assistant-Message gespeichert, optional mit:

- `metadata["agent"]["tool_calls"]`: kompakt persistierte Tool-Events
- `metadata["agent"]["mcp_log"]`: zusammengefasster MCP Live Log (gekürzt, bounded)
- `metadata["agent"]["artifact_relpaths"]`: Relpaths im Worktree (für UI/Rendering)

---

## UI-Features (was der User sieht)

### Agenten-Modal (Settings)

- Template: `templates/partials/agent_modal.html`
- Controller: `static/js/main.js` (`window.agentModal()`)
- Persistenz-Endpunkt: `GET/POST /chat/agent/preference/` (pro `session_uuid`)
- Features:
  - Toggle „Agent Mode“
  - Advanced: Tool-Allowlist (ein-/ausschaltbar)
  - Schließen per Backdrop/Close-Button

### AgentTrace + MCP Live Log (Streaming-Ansicht)

- Template: `templates/partials/send_prompt_response_streaming.html`
- Shared: `templates/partials/shared_send_prompt_response_streaming.html`
- Persistiert (History): `templates/partials/message_assistant.html`

Events werden während SSE verarbeitet und in UI-Elemente geschrieben:

- **Tool-Events** → Tool-Karten / Tool-Panel
- **MCP Live Log** → Terminal-artiger Log-Block
- **Text** → Assistant-Bubble, live gerendert als Markdown

**UX-Entscheidung (aktuell):**

- AgentTrace und MCP Live Log sind **standardmäßig aufgeklappt**, sobald sichtbar (Transparenz).

### Worktree (Dateien)

Worktree-Dateien werden als Dropdown **unter der Antwort** angezeigt (nicht „im Trace“), wenn Dateien vorhanden sind:

- Live: `templates/partials/send_prompt_response_streaming.html`
- History/Reload: `templates/partials/message_assistant.html`
- Shared: `templates/partials/shared_send_prompt_response_streaming.html`

Worktree-Listing via:

- `GET /chat/agent/worktree/<session_uuid>/` (Owner)
- Shared (read-only): `GET /chat/shared/<share_uuid>/worktree/`

---

## Endpunkte (Backend)

### Chat/Streaming

- `POST /chat/prompt/` → erstellt `ChatMessage(role="user")`, liefert Streaming-Partial zurück  
  Datei: `chat/views.py` → `send_prompt()`
- `GET /chat/response/stream/<msg_id>/` → normaler SSE-Stream  
  Datei: `chat/views.py` → `generate_response_stream()`
- `GET /chat/agent/response/stream/<msg_id>/` → Agent-SSE-Stream  
  Datei: `chat/views.py` → `generate_agent_response_stream()`

### Agent Settings

- `GET /chat/agent/preference/?session_uuid=...` → aktuelle Settings
- `POST /chat/agent/preference/` → patch `agent_enabled` und/oder `tools`

Datei: `chat/views.py` → `agent_preference_view()`

### Artefakte / Worktree

- `GET /chat/agent/artifact/<session_uuid>/<relpath>/`  
  Datei: `chat/views.py` → `agent_artifact_view()`
- `GET /chat/agent/worktree/<session_uuid>/`  
  Datei: `chat/views.py` → `agent_worktree_list()`

Shared:

- `GET /chat/shared/<share_uuid>/artifact/<relpath>/`
- `GET /chat/shared/<share_uuid>/worktree/`

---

## SSE-Protokoll (was über den Stream läuft)

Der Server sendet Zeilen im SSE-Format:

- `data: {json}\n\n` für „Events“
- `: keepalive ...\n\n` für Kommentare/Heartbeats (EventSource ignoriert diese, hält aber die Verbindung offen)

Wichtige Keys im JSON:

- `content`: Token/Teilstring der Antwort
- `finish_reason`: Stream-Ende
- `error`: Fehlertext (UI zeigt rot)
- `mcp_log`: eine Logzeile für Live Log
- `tool_call`: strukturierte Tool-Event-Informationen (Start/Status/Result)

Frontend-Parser:

- `templates/partials/send_prompt_response_streaming.html` (JS inline)
- globaler Renderer/Updater in `static/js/main.js` + `static/js/markdown_renderer.js`

---

## Agent-Logik (Planner → Executor → optional Evaluation)

Die Agent-Pipeline lebt in `chat/views.py` in `generate_agent_response_stream()`.

### 1) Start: Agent-Settings & Tool-Allowlist

- Server prüft: `metadata["agent"]["agent_enabled"]`
- Ermittelt Allowlist: alle `tools[key] == true`
- Schreibt Start-Logs in MCP Live Log (statisch, weil immer gleiches Setup)

### 2) Planner

Der Planner ist ein **nicht-streaming LLM-Call**, der als Ergebnis JSON liefern soll:

```json
{ "tool_calls": [ { "tool": "...", "args": {...}, "depends_on": [0] } ] }
```

Implementiert über `_complete_text(...)` (LLM-Completion) und anschließendes robustes JSON-Coercing.

### 3) Deterministic Toolchains (Guardrails)

Weil Planner-Modelle manchmal keine Toolcalls zurückgeben (oder halluzinieren), gibt es erzwungene Ketten, z.B.:

- **Plot-Requests** → ggf. `python.execute` wird erzwungen (Codegen + Parse-Check)
- **Excel/XLSX-Requests** → `python.execute` wird erzwungen (Parsing des User-Pastes → Export)

Ziel: „Wenn der User eindeutig X will, dann **führen wir X deterministisch aus**“.

### 4) Executor

Toolcalls werden **sequenziell** ausgeführt. Wichtige Eigenschaften:

- `depends_on` wird aufgelöst (Kontext/Output kann in Folgeschritten genutzt werden)
- Tool-Results werden gesammelt:
  - `tool_results` (für Logging/ApiLog)
  - `all_tool_results` (iteration-scoped)
- Heartbeat-Mechanik: Blocking Calls laufen in Thread, Server sendet SSE-Kommentare/optional MCP-Progress, damit Proxy-Verbindungen nicht sterben.

### 5) Evaluation / Iterationen

Es existiert ein Iterations-Loop (max. 10), um nach Tool-Schritten neu zu planen.

Pragmatischer Trade-off (aktuell): wenn ein Tool-Batch erfolgreich war, wird häufig **früh gestoppt**, um keine zusätzlichen LLM-Evaluator-Calls zu verbrennen. Das ist stabil, aber weniger „autonom“ als ein voll ausgebauter Loop.

---

## Tool-Ausführung (exakt: wie/wo)

### MCP Tools (`web.*`, `fs.*`, `doc.*`, `kb.*`, `media.*`, `vision.*`)

- Django ruft MCP-Server-Endpunkte via HTTP JSON auf (z.B. `POST {MCP_SERVER_URL}/tools/fs/read`)
- MCP-Server validiert Args, führt aus, schreibt ggf. Artefakte/Dateien in den Worktree

Die Tool-Allowlist wird serverseitig enforced, indem nur erlaubte Tool-Keys ausgeführt werden.

### `python.execute` (Python Sandbox)

Django ruft die Python-Sandbox an:

- Endpoint: `POST {PYTHON_SANDBOX_URL}/tools/python/execute`
- Payload (typisch):
  - `user_id`
  - `session_uuid`
  - `code`
  - `timeout`
  - `cwd` (relativ, optional)
  - `emit_dataframes`, `emit_dataframe_html` (opt-in)

Ergebnis enthält u.a.:

- `stdout`, `stderr`, `exit_code`
- `artifacts`: Liste von Relpaths (z.B. `artifacts/plot_....png`)
- optional DataFrame-Metadaten

### Tool-Result-Summarization

Tool-Results können riesig werden (HTML/Downloads/Text). Vor Evaluation/Final Answer werden sie zusammengefasst (`_summarize_tool_results`) – Preview/Counts statt Full Dumps.

---

## Worktree & Artefakte (Isolation & Auslieferung)

### Isolations-Design

Der Worktree ist pro `(user_id, session_uuid)` isoliert:

```
{MCP_WORKSPACE_ROOT}/user_<user_id>/chat_<session_uuid>/
  artifacts/
  ...
```

### „Neuer Chat + Agent an = neuer Worktree“

Erwartung: ein neuer Chat soll **einen frischen Worktree-Namespace** haben.

Implementiert durch:

- Der Worktree-Scope ist ohnehin session-gebunden (neue UUID → neues Verzeichnis).
- Zusätzlich wird das Root-Verzeichnis (inkl. `artifacts/`) früh erzeugt, sobald Agent aktiviert ist, damit die UI sofort „Worktree vorhanden“ hat.

### Artefakt-Links (share-safe)

Bevorzugte Darstellung ist **`artifact://...`** im Markdown.

Im Frontend wird `artifact://relpath` auf einen same-origin HTTP-Endpunkt gemappt:

- normal: `window.__artifactBaseUrl = /chat/agent/artifact/<session_uuid>/`
- shared: `window.__artifactBaseUrl = /chat/shared/<share_uuid>/artifact/`

---

## Markdown-Rendering & Sicherheitsregeln (Bilder/Links)

Renderer: `static/js/markdown_renderer.js` (`renderMarkdownLive`)

### URL-Sanitizing (wichtig)

- Blockt `javascript:`
- Blockt `data:` (keine Base64-Bilder)
- Blockt `file://`
- Blockt Remote-Images standardmäßig (Privacy) – außer same-origin oder explizit erlaubt

### Artefakte rendern

Erlaubt und gemappt:

- `artifact://artifacts/foo.png` → `__artifactBaseUrl + artifacts/foo.png`
- `artifacts/foo.png` und `/artifacts/foo.png` werden ebenfalls auf Artefakte gemappt

### Streaming vs Final Render

Während Streaming werden Remote Images unterdrückt (Browser-Aborts vermeiden). Lokale Artefakte sind safe und werden gerendert.

---

## Observability / Logs

### MCP Live Log

Der Server emittiert Logzeilen als `mcp_log` SSE-Events. Diese werden:

- live im UI angezeigt
- am Ende (bounded) in `ChatMessage.metadata["agent"]["mcp_log"]` persistiert

### Tool-Events

Tool-Karten werden aus strukturierten Tool-Events erzeugt (Start/Status/Args/Result), sowohl live als auch beim Reload (persistierte Events).

---

## Reliability (Retries / Upstream-Probleme)

AcademicCloud (Gateway) kann transient 5xx/503 liefern. In `chat/api.py` gibt es deshalb Retries mit Backoff/Jitter für:

- `send_message(...)`
- `send_message_stream(...)`

Transiente Statuscodes: `429, 500, 502, 503, 504`

Konfigurierbar via Env:

- `ACADEMIC_API_RETRY_ATTEMPTS` (1–5, default 3)

---

## Was wir in dieser Session konkret geändert haben (Changelog-Notizen)

Diese Punkte erklären „was wir da gemacht haben“ (aus den letzten Änderungen im Repo):

- **UI State Fix**: Klick auf „Neu“ erzwingt „Chats“-Tab aktiv (Arcana → Chats) via `window.activateChatsSidebarTab()` (`static/js/main.js`).
- **Agenten-Modal Position**: Modal sitzt etwas tiefer und bleibt (Desktop) zentriert (`templates/partials/agent_modal.html`).
- **AgentTrace/MCP Live Log**: Standardmäßig aufgeklappt (live + shared + history) und nicht auto-collapsed.
- **Artefakt-Rendering**:
  - `artifacts/...` wird wie `artifact://...` gemappt (kein „Bild blockiert“ bei lokalen Artefakten).
  - Canonicalization + De-Duping von doppelten Artefakt-Embeds im Agent-Finalizer.
- **Worktree UX**:
  - Worktree wird **unter der Antwort** angezeigt (nicht im AgentTrace), und nur bei vorhandenen Dateien eingeblendet.
- **Neuer Chat**:
  - Übernahme der Agent-Settings in neue Session möglich (damit „Agent an“ konsistent bleibt).
  - Worktree-Root wird erzeugt, sobald Agent enabled ist (oder bei neuem Chat übernommen wird).
- **Excel Auto-Toolchain**:
  - Falscher Kino-Export entfernt, stattdessen Parser für gepastete Tabellen.
  - Deterministische Antwort nach erfolgreichem Excel-Tool (keine LLM-Nach-Halluzination).

---

## Offene Punkte / sinnvolle nächste Verbesserungen

- **Planner-Evaluator Loop** klarer machen (Stop-Kriterien, Budget, „goal reached“ statt frühem Stop).
- **Tool Result Contracts** vereinheitlichen (recoverable vs fatal errors).
- **Worktree-Refresh Trigger** event-getrieben nach file-touching Tools (statt nur Timer/Manual Refresh).
- **PDF Validation** bei Downloads (Magic Bytes `%PDF-`), damit „download ok“ nicht HTML-Loginseiten speichert.

