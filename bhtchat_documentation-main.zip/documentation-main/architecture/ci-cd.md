# Delivery-Pipeline

## Pipeline-Stages

1. **Verify**
   - `npm run lint` + `pytest`
   - Build Artefakte für Frontend, Docs und Worker
2. **Package**
   - Docker-Images mit `buildx bake`
   - SBOM Generierung via `syft`
3. **Release**
   - GitHub Release Draft + automatische Changelog-Schnipsel
4. **Deploy**
   - ArgoCD Synchronisation in `staging` → manuelles Promote nach `prod`

## Qualitäts-Gates

- **Security Scan**: Trivy + Grype, Schwellwert „Medium“.
- **Contract Tests**: Prism + Postman Collections.
- **Performance Budgets**: K6 Smoke (P95 < 750 ms für /v1/chat).

## Rollback

- Nutze `scripts/rollback_release.sh <version>`.
- Datenbankmigrationen haben Down-Migrations; bei Breaking Changes existiert Shadow Table.
- Incidents dokumentieren wir im On-Call Playbook und aktualisieren dortige Lessons Learned.

