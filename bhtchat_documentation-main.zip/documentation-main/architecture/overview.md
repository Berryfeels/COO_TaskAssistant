# Systemübersicht

> **Stand:** Dezember 2025 · **Owner:** Platform Team · **Status:** Stable

Die chatbht Plattform besteht aus drei Schichten:

1. **Experience Layer** – Next.js Frontends und native Clients.
2. **API Layer** – Django REST Backend plus Realtime-Gateway (FastAPI).
3. **Intelligence Layer** – orchestrierte LLM-Pipelines, Retrieval-Services und Event-Verarbeitung.

```
[Client] --HTTPS--> [API Gateway] --gRPC--> [Worker Pool]
                ↘                     ↘
                 ↘                     +--> Redis Streams
                  +--> Postgres        +--> OpenAI / Vertex
```

## Domänen

- **Session Services** – erstellen Dialoginstanzen, halten Metadaten und Bezug zu Gesprächspartnern.
- **Knowledge Services** – ingestieren Dokumente, erzeugen Embeddings und pflegen Vektorspeicher.

## Wichtige Eigenschaften

- **Multi-Region ready:** Stateful Komponenten laufen (noch) single-region, aber alle stateless Workloads können in <15 Minuten in Region B ausgerollt werden.
- **Zero-Trust by default:** Jede Anfrage trägt signierte JWTs, Services akzeptieren nur least-privilege Tokens.
- **Observability fertig verdrahtet:** OpenTelemetry Exporter für Traces, Prometheus für Metriken, Loki für Logs.

## Referenzen

- `src/api/schema.graphql` – High-Level API Surface
- `deploy/terraform/` – Infrastruktur-Definition
- Dashboards: Grafana Folder „chatbht / Core“

