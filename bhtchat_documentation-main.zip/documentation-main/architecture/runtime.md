# Laufzeit & Infrastruktur

| Ebene | Technologie | Hinweise |
| --- | --- | --- |
| Container Runtime | Kubernetes (GKE Autopilot) | Workload Identity aktiviert, PodSecurity Standard |
| Datenbank | Cloud SQL Postgres 15 | PITR 7 Tage, tägliche physische Backups |
| Cache | Redis Enterprise Cloud | Zwei Shards, TLS zwingend |
| Warteschlange | Google Pub/Sub + Redis Streams | Pub/Sub für durable Events, Streams für Kurzläufer |

## Traffic Flow

1. **Cloud Armor** filtert Layer-7 Signaturen und rate-limited /v1/chat.
2. **Global Load Balancer** verteilt auf regionale Ingress-Gateways (Istio).
3. **Service Mesh** sorgt für mTLS, Retries und Circuit Breaking.
4. **Background Workers** skalieren horizontal über KEDA, triggern LLM-Aufrufe und persistieren Ergebnisse.

## Deployments

- **CI**: GitHub Actions → BuildKit → Container Registry.
- **CD**: ArgoCD watched `deploy/helm/*.yaml`.
- **Blue/Green** Releases für API, **Canary** für Worker.

## Secrets & Zertifikate

- TLS-Zertifikate werden per Cert-Manager ausgestellt und via SecretStore an Services gebunden.
- Für `docs.chatbht.com` werden Host-Zertifikate außerdem lokal unter `/etc/letsencrypt/live/docs.chatbht.com/` gespiegelt, sodass Container wie das Git-Book direkten TLS-Termination vornehmen können.

## Observability

- `otel-collector` exportiert nach Grafana Cloud (Tempo, Loki, Mimir).
- `alerts/` enthält die PrometheusRule CRDs, Critical Alerts rufen PagerDuty.
- RUM für Frontends via Sentry Performance.

