# Umfassende Bestandsaufnahme: Markdown-Rendering während und nach dem Streaming

## Übersicht

Das System verwendet ein **zweistufiges Rendering-System**:
1. **Während des Streamings**: Client-seitiges JavaScript (`renderMarkdownLive`) für Echtzeit-Anzeige
2. **Nach dem Streaming**: Server-seitiges Python-Rendering (`markdown_filters.markdown`) für finale Darstellung

**Problem**: Die beiden Rendering-Methoden sind unterschiedlich implementiert und können zu Inkonsistenzen führen.

---

## 1. BACKEND-RENDERING (Server-seitig)

### 1.1 Endpoint: `/chat/render-markdown/`

**Datei**: `chat/views.py` (Zeile 1808-1819)

```python
@require_http_methods(["POST"])
def render_markdown(request):
    """Render markdown content and return HTML. Accessible without login for shared chats."""
    from django.utils.html import mark_safe
    from .templatetags.markdown_filters import markdown
    
    content = request.POST.get('content', '')
    if not content:
        return JsonResponse({'html': ''})
    
    # Render markdown using the filter function
    html_content = markdown(content)
    return JsonResponse({'html': str(html_content)})
```

**Verwendung**: Wird von allen `finalizeMessage()` Funktionen aufgerufen, um das finale HTML zu generieren.

---

### 1.2 Markdown-Filter: `markdown_filters.markdown`

**Datei**: `chat/templatetags/markdown_filters.py` (Zeile 88-125)

**Funktionsweise**:
1. **LaTeX-Schutz**: LaTeX-Formeln werden erkannt und durch Platzhalter ersetzt
2. **Markdown-Rendering**: Verwendet Python `markdown` Library mit Extensions:
   - `fenced_code`: Code-Blöcke mit ```
   - `codehilite`: Syntax-Highlighting via Pygments
   - `tables`: GitHub-ähnliche Tabellen
3. **LaTeX-Wiederherstellung**: LaTeX-Formeln werden wieder eingefügt

**Erkannte Markdown-Elemente**:
- ✅ Code-Blöcke: ` ```language\ncode\n``` `
- ✅ Inline-Code: `` `code` ``
- ✅ Tabellen: `| Spalte 1 | Spalte 2 |`
- ✅ LaTeX: `$$...$$` (display) und `$...$` (inline)
- ✅ Headers: `#`, `##`, `###`
- ✅ Listen: `*`, `-`, `1.`
- ✅ Links: `[Text](URL)`
- ✅ Bold/Italic: `**bold**`, `*italic*`

**Konfiguration**:
- Pygments-Style: `monokai`
- Language-Guessing: aktiviert
- Line-Numbers: deaktiviert

---

## 2. FRONTEND-RENDERING WÄHREND STREAMING (Client-seitig)

### 2.1 Funktion: `window.renderMarkdownLive`

**Problem**: Es gibt **VERSCHIEDENE Implementierungen** in verschiedenen Templates!

#### Variante 1: Standard (send_prompt_response_streaming.html, shared_chat_streaming.html)

**Dateien**:
- `templates/partials/send_prompt_response_streaming.html` (Zeile 122-172)
- `templates/partials/shared_chat_streaming.html` (Zeile 141-191)
- `templates/shared_chat.html` (Zeile 236-279)

**Implementierung**:
```javascript
window.renderMarkdownLive = function(text) {
    let result = text;
    
    // 1. Code-Blöcke schützen
    const codeBlocks = [];
    result = result.replace(/```(\w+)?\n?([\s\S]*?)```/g, function(match, lang, code) {
        const placeholder = `__CODE_BLOCK_${codeBlocks.length}__`;
        codeBlocks.push({ lang: lang || 'text', code: code.trim() });
        return placeholder;
    });
    
    // 2. Markdown-Elemente verarbeiten
    result = result
        // Headers
        .replace(/^### (.*$)/gim, '<h3 class="text-lg font-bold mt-4 mb-2">$1</h3>')
        .replace(/^## (.*$)/gim, '<h2 class="text-xl font-bold mt-4 mb-2">$1</h2>')
        .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold mt-4 mb-2">$1</h1>')
        
        // Inline-Code
        .replace(/`([^`]+)`/g, '<code class="bg-gray-200 dark:bg-[#303030] px-1 py-0.5 rounded text-sm font-mono">$1</code>')
        
        // Bold/Italic
        .replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold">$1</strong>')
        .replace(/\*(.*?)\*/g, '<em class="italic">$1</em>')
        
        // Listen
        .replace(/^\* (.*$)/gim, '<li class="ml-4">$1</li>')
        .replace(/^- (.*$)/gim, '<li class="ml-4">$1</li>')
        .replace(/^\d+\. (.*$)/gim, '<li class="ml-4">$1</li>')
        
        // Links
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="text-blue-600 dark:text-blue-400 hover:underline" target="_blank">$1</a>')
        
        // Zeilenumbrüche
        .replace(/\n\n/g, '</p><p class="my-2">')
        .replace(/\n/g, '<br>')
        
        // Paragraph-Wrapping
        .replace(/^([^<].*)/, '<p class="my-2">$1')
        .replace(/([^>])$/, '$1</p>');
    
    // 3. Code-Blöcke wiederherstellen
    codeBlocks.forEach((block, index) => {
        const placeholder = `__CODE_BLOCK_${index}__`;
        const codeHtml = `<pre class="bg-gray-800 text-gray-100 p-4 rounded-lg overflow-x-auto my-4 max-w-full" style="..."><code class="language-${block.lang}" style="...">${block.code}</code></pre>`;
        result = result.replace(placeholder, codeHtml);
    });
    
    return result;
};
```

**Erkannte Elemente**:
- ✅ Code-Blöcke: ` ```language\ncode\n``` `
- ✅ Inline-Code: `` `code` ``
- ✅ Headers: `#`, `##`, `###`
- ✅ Listen: `*`, `-`, `1.`
- ✅ Links: `[Text](URL)`
- ✅ Bold/Italic: `**bold**`, `*italic*`
- ❌ **TABELLEN: NICHT ERKANNT!**
- ❌ **LaTeX: NICHT ERKANNT!**

---

#### Variante 2: Arcana (vereinfacht)

**Datei**: `templates/partials/arcana_send_prompt_response_streaming.html` (Zeile 186-214)

**Implementierung**:
```javascript
if (!window.renderMarkdownLive) {
    window.renderMarkdownLive = function(text) {
        let result = text;
        
        // Code-Blöcke schützen
        const codeBlocks = [];
        result = result.replace(/```(\w+)?\n?([\s\S]*?)```/g, function(match, lang, code) {
            const placeholder = `__CODE_BLOCK_${codeBlocks.length}__`;
            codeBlocks.push({ lang: lang || 'text', code: code.trim() });
            return placeholder;
        });
        
        // Vereinfachte Markdown-Verarbeitung
        result = result
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code class="bg-gray-100 dark:bg-[#303030] px-1 py-0.5 rounded text-sm">$1</code>')
            .replace(/\n/g, '<br>');
        
        // Code-Blöcke wiederherstellen
        codeBlocks.forEach((block, index) => {
            const placeholder = `__CODE_BLOCK_${index}__`;
            const codeHtml = `<pre class="bg-gray-100 dark:bg-[#303030] p-3 rounded overflow-x-auto max-w-full" style="..."><code class="language-${block.lang}" style="...">${block.code}</code></pre>`;
            result = result.replace(placeholder, codeHtml);
        });
        
        return result;
    };
}
```

**Erkannte Elemente**:
- ✅ Code-Blöcke: ` ```language\ncode\n``` `
- ✅ Inline-Code: `` `code` ``
- ✅ Bold/Italic: `**bold**`, `*italic*`
- ❌ **HEADERS: NICHT ERKANNT!**
- ❌ **LISTEN: NICHT ERKANNT!**
- ❌ **LINKS: NICHT ERKANNT!**
- ❌ **TABELLEN: NICHT ERKANNT!**
- ❌ **LaTeX: NICHT ERKANNT!**

---

### 2.2 Verwendung während Streaming

**Funktion**: `updateContentLive(content)`

Wird bei jedem eingehenden Token aufgerufen:

```javascript
function updateContentLive(content) {
    const isMarkdownView = messageElement.__x.$data.isMarkdownView;
    
    if (isMarkdownView) {
        // Client-seitiges Rendering
        contentElement.innerHTML = window.renderMarkdownLive(content);
        
        // Syntax-Highlighting
        contentElement.querySelectorAll('pre code').forEach((block) => {
            if (window.hljs) {
                window.hljs.highlightElement(block);
            }
        });
        
        // Copy-Buttons hinzufügen
        if (window.addCopyButtons) {
            window.addCopyButtons(contentElement);
        }
    } else {
        // Plaintext-Ansicht
        contentElement.innerHTML = `<div class="whitespace-pre-wrap...">${content}</div>`;
    }
}
```

**Besonderheit bei Arcana**: 
- Verwendet **SERVER-SEITIGES Rendering** auch während Streaming!
- `updateContentLive` macht einen Fetch-Request zu `/chat/render-markdown/`
- Fallback auf `renderMarkdownLive` bei Fehler

---

## 3. FRONTEND-RENDERING NACH STREAMING (Finalisierung)

### 3.1 Funktion: `finalizeMessage()`

**Zweck**: Ersetzt das client-seitig gerenderte HTML durch server-seitig gerendertes HTML.

**Ablauf**:
1. Akkumulierten Content sammeln (`fullContent`)
2. POST-Request zu `/chat/render-markdown/`
3. Server-seitiges Rendering mit `markdown_filters.markdown`
4. HTML in DOM einfügen
5. LaTeX-Rendering mit KaTeX
6. Copy-Buttons hinzufügen

**Implementierungen**:

#### Variante 1: Standard Chat
**Datei**: `templates/partials/send_prompt_response_streaming.html` (Zeile 327-391)

```javascript
function finalizeMessage() {
    fetch('{% url "chat:render-markdown" %}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRFToken': document.querySelector('input[name="csrfmiddlewaretoken"]').value
        },
        body: `content=${encodeURIComponent(fullContent)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.html) {
            messageContentElement.innerHTML = data.html;
            messageContentElement.setAttribute('data-original-content', fullContent);
            
            // LaTeX-Rendering
            if (window.renderMathInElement && messageContainer) {
                window.renderMathInElement(messageContainer, {...});
            }
            
            // Copy-Buttons
            if (window.addCopyButtons) {
                window.addCopyButtons(messageContentElement);
            }
        }
    });
}
```

#### Variante 2: Shared Chat
**Datei**: `templates/partials/shared_chat_streaming.html` (Zeile 346-410)
- Identisch zu Variante 1

#### Variante 3: Shared Send Prompt
**Datei**: `templates/partials/shared_send_prompt_response_streaming.html` (Zeile 257-312)
- Identisch zu Variante 1

#### Variante 4: Arcana
**Datei**: `templates/partials/arcana_send_prompt_response_streaming.html` (Zeile 369-419)
- Identisch zu Variante 1

#### Variante 5: Message Assistant Streaming
**Datei**: `templates/partials/message_assistant_streaming.html` (Zeile 138-195)
- Verwendet `/chat/render-markdown/` (hardcoded URL statt Template-Tag)
- Kein Streaming-Rendering während des Streamings (nur `textContent`)

---

## 4. CHAT-TYPEN UND TEMPLATES

### 4.1 Standard Chat
- **Template**: `send_prompt_response_streaming.html`
- **Streaming-Endpoint**: `chat:chat-response-stream`
- **Rendering**: Client-seitig während Streaming, Server-seitig nach Streaming

### 4.2 Shared Chat (mit Prompting)
- **Template**: `shared_chat_streaming.html`
- **Streaming-Endpoint**: `chat:shared-chat-response-stream`
- **Rendering**: Client-seitig während Streaming, Server-seitig nach Streaming

### 4.3 Shared Chat (ohne Prompting, nur Antwort)
- **Template**: `shared_send_prompt_response_streaming.html`
- **Streaming-Endpoint**: `chat:shared-chat-response-stream`
- **Rendering**: Client-seitig während Streaming, Server-seitig nach Streaming

### 4.4 Arcana Chat
- **Template**: `arcana_send_prompt_response_streaming.html`
- **Streaming-Endpoint**: `chat:arcana-response-stream`
- **Rendering**: **SERVER-SEITIG während Streaming** (anders als andere!), Server-seitig nach Streaming

### 4.5 Message Assistant Streaming (HTMX)
- **Template**: `message_assistant_streaming.html`
- **Streaming-Endpoint**: `/chat/response/stream/{id}/`
- **Rendering**: **KEIN Rendering während Streaming** (nur `textContent`), Server-seitig nach Streaming

---

## 5. PROBLEME UND INKONSISTENZEN

### 5.1 Unterschiedliche `renderMarkdownLive` Implementierungen

| Feature | Standard | Arcana |
|---------|----------|--------|
| Code-Blöcke | ✅ | ✅ |
| Inline-Code | ✅ | ✅ |
| Headers | ✅ | ❌ |
| Listen | ✅ | ❌ |
| Links | ✅ | ❌ |
| Bold/Italic | ✅ | ✅ |
| Tabellen | ❌ | ❌ |
| LaTeX | ❌ | ❌ |

### 5.2 Unterschiedliche Streaming-Strategien

1. **Standard/Shared**: Client-seitiges Rendering während Streaming
2. **Arcana**: Server-seitiges Rendering während Streaming (Fetch-Request pro Update!)
3. **Message Assistant**: Kein Rendering während Streaming

### 5.3 Fehlende Features im Client-seitigen Rendering

- ❌ **Tabellen**: Werden nicht erkannt
- ❌ **LaTeX**: Wird nicht erkannt
- ❌ **Code-Syntax-Highlighting**: Nur via `hljs` nachträglich, nicht während Streaming
- ❌ **Komplexe Listen**: Nur einfache Listen, keine verschachtelten

### 5.4 Inkonsistente Code-Block-Formatierung

**Standard**:
```html
<pre class="bg-gray-800 text-gray-100 p-4 rounded-lg...">
```

**Arcana**:
```html
<pre class="bg-gray-100 dark:bg-[#303030] p-3 rounded...">
```

### 5.5 Unterschiedliche Regex-Patterns

**Code-Block-Erkennung**:
- Standard: `/```(\w+)?\n?([\s\S]*?)```/g`
- Arcana: `/```(\w+)?\n?([\s\S]*?)```/g` (identisch)

**Inline-Code**:
- Standard: `/`([^`]+)`/g`
- Arcana: `/`(.*?)`/g` (unterschiedlich - Arcana ist weniger strikt)

---

## 6. DATEIEN-ÜBERSICHT

### Backend
- `chat/views.py` (Zeile 1808-1819): `render_markdown` Endpoint
- `chat/templatetags/markdown_filters.py`: Server-seitiges Markdown-Rendering

### Frontend Templates (Streaming)
- `templates/partials/send_prompt_response_streaming.html`: Standard Chat
- `templates/partials/shared_chat_streaming.html`: Shared Chat mit Prompting
- `templates/partials/shared_send_prompt_response_streaming.html`: Shared Chat ohne Prompting
- `templates/partials/arcana_send_prompt_response_streaming.html`: Arcana Chat
- `templates/partials/message_assistant_streaming.html`: HTMX-basiertes Streaming

### Frontend Templates (Statisch)
- `templates/partials/message_assistant.html`: Statische Assistant-Nachrichten
- `templates/shared_chat.html`: Shared Chat Haupt-Template

### Frontend JavaScript
- `static/js/main.js`: Globale Funktionen (`toggleExistingMessageView`, etc.)

---

## 7. ZUSAMMENFASSUNG DER PROBLEME

### Hauptprobleme:
1. **Zwei verschiedene Rendering-Implementierungen** (Client vs. Server)
2. **Verschiedene `renderMarkdownLive` Varianten** mit unterschiedlichen Features
3. **Fehlende Features** im Client-Rendering (Tabellen, LaTeX)
4. **Inkonsistente Streaming-Strategien** (Client vs. Server während Streaming)
5. **Unterschiedliche Code-Block-Styles** zwischen Varianten
6. **Keine einheitliche Behandlung** verschiedener Markdown-Formate von Sprachmodellen

### Empfehlungen:
1. **Einheitliche `renderMarkdownLive` Funktion** mit allen Features
2. **Tabellen-Erkennung** hinzufügen
3. **LaTeX-Erkennung** hinzufügen (oder zumindest Platzhalter)
4. **Einheitliche Streaming-Strategie** (entweder alle Client-seitig oder alle Server-seitig)
5. **Einheitliche Code-Block-Formatierung**
6. **Robustere Regex-Patterns** für verschiedene Markdown-Varianten

