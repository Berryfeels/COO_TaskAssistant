# Ressourcen & Links

- **Dashboards**
  - Grafana: `https://grafana.chatbht.com/d/chatbht-core`
  - Kibana: `https://logs.chatbht.com/`
- **Wissensquellen**
  - Product Briefs (`/docs/product/briefs`)
  - Conversation Design Library (`/docs/convo-design`)
- **Kommunikation**
  - Slack `#docs`, `#incident`, `#release`
  - Statuspage: `https://status.chatbht.com`
- **Tools**
  - Figma Library `chatbht / Design System`
  - Shortcut Project `DOCS`

