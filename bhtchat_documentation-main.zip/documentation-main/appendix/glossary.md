# Glossar

- **Bridge Prompt** – Template, das Benutzerinput in strukturierte Slots übersetzt.
- **Context Window** – Tokenbudget eines Modells; bei GPT-4.1 aktuell 128k.
- **Failover Region** – Zweiter Cloud-Stack (europe-west4), bereit für aktive Umschaltung.
- **Playbook** – Schritt-für-Schritt-Anleitung für wiederkehrende Betriebsaufgaben.
- **RAG** – Retrieval Augmented Generation; bei uns: Vertex Matching Engine + custom reranker.

