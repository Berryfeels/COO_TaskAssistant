# Chat-BHT – Einführung

Chat-BHT bezeichnet ein an der Berliner Hochschule für Technik entwickeltes Werkzeug , welches den sicheren Zugang zu leistungsfähigen Large-Language-Modellen in den Dienst von Studium, Lehre und Forschung stellt. Grundlage bildet die offene Hochleistungsinfrastruktur der GWDG und des **KI-Servicezentrums KISSKI**, orchestriert über den **Scalable Artificial Intelligence Accelerator (SAIA)**. 


Chat-BHT soll Lernende, Lehrende und Forschende befähigen, eigene Ideen zu entwickeln, Wissen zu teilen und komplexe Probleme kollaborativ zu lösen – chatBHT soll unabhängig von zentralen KI-Dienstleisten im Hochschulaltag unterstützen. Die vetfügbaren Sprachmodelle unterstützen als Mentor, Sparringspartner, Ideengeber, Debug-Hilfe oder Analysewerkzeug.





chatBHT verfolgt das Ziel, eine faire und verantwortungsvolle Nutzung von KI in der Hochschulbildung zu ermöglichen. Statt isolierter Einzelzugänge zu externen Plattformen entsteht eine Infrastruktur, die Gleichberechtigte Nutzung von KI-Teechnologien für alle Statusgruppen ermöglicht – von der Erstsemesterveranstaltung bis zur Promotion. 

Chat-BHT befindet sich seit April 2025 in fortlaufender Entwicklung.






## Kontakt

Source-Code und Dokumentation : 
`gitlab.bht-berlin.de/ai/gangwai`

Entwicklung: 
gordon.dyballa@bht-berlin.de

gdyballa.bht-pages.de/contact


## Referenzen

Kirchner H. et al., *Free Access to Private AI – AI-Services on the HPC*, DFN 81. Betriebs­tagung, 09 / 2024

Doosthosseini A. et al., *Chat AI: A Seamless Slurm-Native Solution for HPC-Based Services*, arXiv 2407.00110 (2024)