# MCP Server Architektur - Detaillierte Dokumentation

## Übersicht

Das Gangwai-System verwendet zwei separate MCP (Model Context Protocol) Server als Microservices, die dem AI-Agent verschiedene Tools zur Verfügung stellen. Diese Server sind isoliert, sicher und ermöglichen es dem Agent, komplexe Aufgaben wie Datenanalyse, Visualisierung und Dateiverwaltung durchzuführen.

## Architektur-Übersicht

```
┌─────────────────┐
│  Django Web App │
│  (chat/views.py)│
└────────┬────────┘
         │
         ├─────────────────┬─────────────────┐
         │                 │                 │
         ▼                 ▼                 ▼
┌────────────────┐ ┌────────────────┐ ┌──────────────┐
│  MCP Server    │ │ Python Sandbox │ │  PostgreSQL  │
│  (Port 9000)   │ │  (Port 9100)   │ │   Database   │
│                │ │                │ │              │
│  - Web Tools   │ │  - Code Exec   │ │              │
│  - FS Tools    │ │  - Data Sci    │ │              │
│  - Media Tools │ │  - Viz         │ │              │
└────────────────┘ └────────────────┘ └──────────────┘
         │                 │
         └────────┬─────────┘
                  │
                  ▼
         ┌─────────────────┐
         │ Shared Volume    │
         │ /mcp_workspaces │
         │ (Docker Volume)  │
         └─────────────────┘
```

## 1. MCP Server (Web/FS/Media Tools)

**Port:** 9000  
**Technologie:** FastAPI + Uvicorn  
**Zweck:** Bereitstellung von Web-Such-, Download-, Dateisystem- und Media-Tools

### 1.1 Technologie-Stack

- **Framework:** FastAPI 0.115.6
- **ASGI Server:** Uvicorn 0.30.6 (Standard)
- **HTTP Client:** httpx 0.27.2 (async)
- **Web Scraping:** BeautifulSoup4 4.12.3 + lxml 5.3.0
- **Suchmaschine:** duckduckgo_search 6.3.7
- **Media Extraction:** yt-dlp (unpinned, für aktuelle Extractor-Fixes)
- **KB / RAG Storage:** Postgres + pgvector (psycopg3 + pgvector client)
- **Python Version:** 3.11-slim (Docker Base Image)

### 1.2 Workspace-Struktur und Isolation

#### Verzeichnisstruktur
```
/workspace/
├── user_{user_id}/
│   ├── chat_{session_uuid_1}/
│   │   ├── artifacts/
│   │   ├── downloaded_file.csv
│   │   └── analysis.py
│   └── chat_{session_uuid_2}/
│       └── ...
└── ...
```

#### Sicherheitsregeln

1. **User-Isolation:** Jeder User hat sein eigenes Verzeichnis (`user_{user_id}/`)
2. **Session-Isolation:** Jeder Chat hat sein eigenes Arbeitsverzeichnis (`chat_{session_uuid}/`)
3. **Path Traversal Protection:** 
   - `_session_root()` validiert `user_id` (nur Zahlen) und `session_uuid` (8-64 hex chars)
   - `_safe_join()` verhindert Pfade außerhalb des Workspace-Roots
   - Alle Pfade werden mit `resolve()` normalisiert und gegen `WORKSPACE_ROOT` geprüft
4. **Lazy Directory Creation:** Verzeichnisse werden nur erstellt, wenn der Agent-Modus aktiv ist

### 1.3 Verfügbare Tools

#### 1.3.1 `web.search` - Websuche

**Endpoint:** `POST /tools/web/search`

**Request Schema:**
```python
{
    "query": str,           # Suchanfrage (1-400 Zeichen)
    "language": str,        # Standard: "de-de"
    "safesearch": str,      # Standard: "moderate"
    "max_results": int      # Standard: 8, Range: 1-25
}
```

**Funktionalität:**
- Verwendet DuckDuckGo Search API
- Gibt strukturierte Suchergebnisse zurück (Titel, URL, Snippet)
- Unterstützt verschiedene Sprachen und SafeSearch-Einstellungen

**Constraints:**
- Maximale Anzahl Ergebnisse: 25
- Query-Länge: 1-400 Zeichen

#### 1.3.2 `web.fetch` - Webseiten-Inhalt abrufen

**Endpoint:** `POST /tools/web/fetch`

**Request Schema:**
```python
{
    "url": str,                    # URL (1-2000 Zeichen)
    "timeout": int,                # Standard: 30s, Range: 1-120s
    "follow_redirects": bool,      # Standard: True
    "max_chars": int,              # Standard: 250.000, Range: 1K-2M
    "extract_text": bool           # Standard: True
}
```

**Funktionalität:**
- Lädt HTML-Inhalt von URLs
- Extrahiert Text mit BeautifulSoup (wenn `extract_text=True`)
- Folgt Redirects optional
- Begrenzt die Größe des zurückgegebenen Inhalts

**Constraints:**
- Maximale Content-Größe: 2.000.000 Zeichen
- Timeout: 1-120 Sekunden
- Unterstützt nur UTF-8 Text

#### 1.3.3 `web.download` - Dateien herunterladen

**Endpoint:** `POST /tools/web/download`

**Request Schema:**
```python
{
    "user_id": str,                # User-ID (validiert)
    "session_uuid": str,           # Session-UUID (validiert)
    "url": str,                    # Download-URL (1-2000 Zeichen)
    "path": str,                   # Relativer Pfad im Workspace (optional)
    "timeout": int,                # Standard: 60s, Range: 1-300s
    "follow_redirects": bool,      # Standard: True
    "max_bytes": int               # Standard: 50MB, Range: 1MB-100MB
}
```

**Funktionalität:**
- Lädt binäre Dateien (CSV, Excel, PDF, Bilder, etc.) direkt in den Workspace
- Extrahiert Dateinamen aus URL, falls kein Pfad angegeben
- Speichert Dateien im Session-Workspace
- Unterstützt große Dateien bis 100MB

**Constraints:**
- Maximale Dateigröße: 100MB
- Timeout: 1-300 Sekunden
- Dateiname wird aus URL extrahiert, falls nicht angegeben

**Sicherheit:**
- Dateien werden nur im Session-Workspace gespeichert
- Path Traversal wird durch `_safe_join()` verhindert

#### 1.3.4 `fs.list` - Verzeichnis auflisten

**Endpoint:** `POST /tools/fs/list`

**Request Schema:**
```python
{
    "user_id": str,                # User-ID
    "session_uuid": str,           # Session-UUID
    "path": str,                   # Relativer Pfad (optional, Standard: "")
    "recursive": bool              # Standard: False
}
```

**Funktionalität:**
- Listet Dateien und Verzeichnisse im Session-Workspace auf
- Unterstützt rekursive Auflistung
- Gibt Metadaten zurück (Name, Typ, Größe)

**Constraints:**
- Nur Zugriff innerhalb des Session-Workspace
- Rekursive Auflistung kann bei großen Verzeichnissen langsam sein

#### 1.3.5 `fs.read` - Datei lesen

**Endpoint:** `POST /tools/fs/read`

**Request Schema:**
```python
{
    "user_id": str,                # User-ID
    "session_uuid": str,           # Session-UUID
    "path": str,                   # Relativer Pfad zur Datei
    "max_bytes": int               # Standard: 2MB, Range: 1KB-2MB
}
```

**Funktionalität:**
- Liest Textdateien aus dem Workspace
- Dekodiert als UTF-8
- Begrenzt die Größe des gelesenen Inhalts

**Constraints:**
- Maximale Dateigröße: 2MB
- Nur UTF-8 Textdateien
- Datei muss existieren und eine Datei sein (kein Verzeichnis)

**Fehlerbehandlung:**
- 404: Datei nicht gefunden
- 413: Datei zu groß
- 415: Datei ist nicht UTF-8 Text

#### 1.3.6 `fs.write` - Datei schreiben

**Endpoint:** `POST /tools/fs/write`

**Request Schema:**
```python
{
    "user_id": str,                # User-ID
    "session_uuid": str,           # Session-UUID
    "path": str,                   # Relativer Pfad zur Datei
    "content": str,                # Dateiinhalt (UTF-8 Text)
    "overwrite": bool              # Standard: True
}
```

**Funktionalität:**
- Schreibt Textdateien in den Workspace
- Erstellt übergeordnete Verzeichnisse automatisch
- Überschreibt bestehende Dateien, wenn `overwrite=True`

**Constraints:**
- Nur UTF-8 Text
- Kann keine Verzeichnisse überschreiben
- Pfad muss innerhalb des Session-Workspace liegen

**Sicherheit:**
- Verhindert Überschreiben von Verzeichnissen (IsADirectoryError)
- Path Traversal wird durch `_safe_join()` verhindert
- Parent-Verzeichnisse werden automatisch erstellt

#### 1.3.7 `media.ytdlp.info` - Media-Metadaten extrahieren

**Endpoint:** `POST /tools/media/ytdlp/info`

**Request Schema:**
```python
{
    "url": str,                    # Media-URL (1-2000 Zeichen)
    "timeout": int,                # Standard: 60s, Range: 1-120s
    "no_playlist": bool,           # Standard: True
    "extract_flat": bool,          # Standard: False
    "no_check_certificate": bool,  # Standard: False
    "fields": list[str]            # Optional: Spezifische Felder
}
```

**Funktionalität:**
- Extrahiert Metadaten von YouTube, TikTok, etc. ohne Download
- Verwendet yt-dlp für Extraktion
- Gibt strukturierte JSON-Metadaten zurück

**Constraints:**
- Timeout: 1-120 Sekunden
- Lädt keine Medien herunter, nur Metadaten
- Unterstützt verschiedene Video-Plattformen

#### 1.3.8 `kb.*` - Deterministische Knowledge-Base (Ingestion + Retrieval)

**Ziel:** Produktionsreife Abbildung einer RAG-Pipeline als **wenige deterministische Toolcalls** (statt agentic Fetch-Schleifen): Web/PDF → Filter → Chunking → Embeddings → persistenter Vektorindex → Retrieval.

**Wichtig (Embedding-Dimensionen):**
- Der KB-Store verwendet **`halfvec`** und unterstützt damit **bis zu 4000 Dimensionen**.
- Modelle wie `e5-mistral-7b-instruct` (4096-d) sind dafür weiterhin **nicht kompatibel**.
- Default ist daher `qwen3-embedding-4b` (aktuell 2560-d → passt in `halfvec`). Alternativ: dedizierte Vector-DB (Qdrant/Milvus/Weaviate) oder Dim-Reduction.

**DB Voraussetzung (einmalig):**
- In der DB muss `CREATE EXTENSION vector;` verfügbar sein (Image `pgvector/pgvector:pg16` empfohlen).

##### 1.3.8.1 `kb.space.ensure` - Namespace/Space initialisieren (idempotent)

**Endpoint:** `POST /tools/kb/space/ensure`

```python
{
  "user_id": str,
  "session_uuid": str
}
```

**Response:** liefert `tool_result` (Timing/Preview) und stellt sicher, dass die KB-Tabellen existieren.

##### 1.3.8.2 `kb.space.stats` - Space-Statistiken

**Endpoint:** `POST /tools/kb/space/stats`

```python
{
  "user_id": str,
  "session_uuid": str,
  "namespace": str  # z.B. "web"|"document"|"chat"
}
```

**Response:** `documents`, `chunks`, `embedding_models` + `tool_result`.

##### 1.3.8.3 `kb.ingest.web` - Crawl + Filter + Chunk + Embed + Upsert

**Endpoint:** `POST /tools/kb/ingest/web`

```python
{
  "user_id": str,
  "session_uuid": str,
  "url": str,
  "crawl_options": {
    "namespace": "web",
    "embedding_model": "qwen3-embedding-4b",
    "same_domain": true,
    "allowed_domains": ["example.org"],
    "allowed_path_prefixes": ["/docs/"],
    "max_pages": 50,
    "max_depth": 2,
    "max_runtime_s": 120,
    "per_page_max_chars": 250000,
    "strip_tracking_params": true,
    "min_words": 40,
    "chunk_chars": 1200,
    "overlap": 200,
    "max_chunks_per_page": 80,
    "embed_timeout_s": 60
  }
}
```

**Response:** `pages_ok/pages_failed`, `chunks_added/chunks_skipped`, `sources_sample` + `tool_result` und ein `kb/artifacts/*_manifest.json` im Workspace.

##### 1.3.8.4 `kb.ingest.pdf` - Docling → Chunk → Embed → Upsert

**Endpoint:** `POST /tools/kb/ingest/pdf`

```python
{
  "user_id": str,
  "session_uuid": str,
  "source": str,  # Workspace-Pfad ODER URL
  "options": {
    "namespace": "document",
    "embedding_model": "qwen3-embedding-4b",
    "chunk_chars": 1200,
    "overlap": 200,
    "max_chunks": 400,
    "docling_timeout_s": 120,
    "embed_timeout_s": 60
  }
}
```

##### 1.3.8.5 `kb.retrieve` - Top-k Retrieval

**Endpoint:** `POST /tools/kb/retrieve`

```python
{
  "user_id": str,
  "session_uuid": str,
  "query": str,
  "k": 8,
  "namespace": "web",
  "embedding_model": "qwen3-embedding-4b"
}
```

**Response:** `hits=[{chunk_id, score, text_preview, source_type, source_id, title, url, chunk_index}]` + `tool_result`.

### 1.4 Sicherheitsmechanismen

1. **Input-Validierung:**
   - Pydantic Models für alle Requests
   - Regex-Validierung für `user_id` und `session_uuid`
   - Längen- und Range-Validierung für alle Parameter

2. **Path-Sicherheit:**
   - `_safe_join()` verhindert Path Traversal
   - Alle Pfade werden gegen `WORKSPACE_ROOT` geprüft
   - Relative Pfade werden normalisiert

3. **Resource-Limits:**
   - Maximale Dateigrößen (2MB für fs.read, 100MB für web.download)
   - Timeouts für alle Netzwerk-Operationen
   - Maximale Anzahl Suchergebnisse

4. **Isolation:**
   - Jeder User hat sein eigenes Verzeichnis
   - Jede Session hat ihr eigenes Arbeitsverzeichnis
   - Keine Cross-User-Zugriffe möglich

## 2. Python Sandbox Server

**Port:** 9100  
**Technologie:** FastAPI + Uvicorn + Python 3.11  
**Zweck:** Sichere Ausführung von Python-Code für Datenanalyse und Visualisierung

### 2.1 Technologie-Stack

#### Core Libraries
- **Framework:** FastAPI 0.115.6
- **ASGI Server:** Uvicorn 0.30.6
- **Python Version:** 3.11-slim

#### Data Science Libraries
- **NumPy:** 2.1.3 - Numerische Berechnungen
- **Pandas:** 2.2.3 - Datenanalyse und DataFrames
- **SciPy:** 1.14.1 - Wissenschaftliche Berechnungen
- **scikit-learn:** 1.5.2 - Machine Learning
- **statsmodels:** 0.14.4 - Statistische Modelle

#### Visualisierung
- **Matplotlib:** 3.9.2 - Plotting (Backend: Agg, non-interactive)
- **Seaborn:** 0.13.2 - Statistische Visualisierungen
- **Altair:** 5.5.0 - Deklarative Visualisierungen (Vega-Lite)
- **Plotly:** 5.24.1 - Interaktive Visualisierungen
- **Kaleido:** (unpinned) - Plotly Export

#### Datenformate
- **openpyxl:** 3.1.5 - Excel-Dateien
- **xlsxwriter:** (unpinned) - Excel-Schreiben
- **pyarrow:** 18.1.0 - Parquet, Arrow
- **pypdf:** (unpinned) - PDF-Verarbeitung
- **python-docx:** (unpinned) - Word-Dokumente
- **odfpy:** (unpinned) - OpenDocument

#### Geo/Maps
- **folium:** (unpinned) - Interaktive Karten
- **branca:** (unpinned) - Folium-Dependency
- **geopy:** (unpinned) - Geocoding

#### Bilder/Graphics
- **Pillow:** (unpinned) - Bildverarbeitung
- **svgwrite:** (unpinned) - SVG-Generierung
- **cairosvg:** (unpinned) - SVG zu PNG/PDF

#### Serialisierung
- **cloudpickle:** 3.1.1 - Erweiterte Pickle-Funktionalität
- **orjson:** (unpinned) - Schnelle JSON-Serialisierung
- **ujson:** (unpinned) - Alternative JSON-Implementation
- **msgpack:** (unpinned) - Binäre Serialisierung
- **pyyaml:** (unpinned) - YAML-Parsing

#### Weitere Libraries
- **BeautifulSoup4:** 4.12.3 - HTML/XML-Parsing
- **lxml:** 5.3.0 - XML/HTML-Verarbeitung
- **tabulate:** 0.9.0 - Tabellen-Formatierung
- **jinja2:** (unpinned) - Template-Engine
- **markdown:** (unpinned) - Markdown-Parsing
- **rich:** (unpinned) - Terminal-Formatierung
- **httpx:** (unpinned) - HTTP-Client
- **requests:** (unpinned) - HTTP-Client (Legacy)
- **networkx:** (unpinned) - Graph-Analyse
- **faker:** (unpinned) - Test-Daten-Generierung
- **tqdm:** (unpinned) - Progress Bars

### 2.2 Workspace-Struktur

```
/workspace/
├── user_{user_id}/
│   └── chat_{session_uuid}/
│       ├── artifacts/
│       │   ├── plot_1234567890.png
│       │   ├── (keine latest.png mehr; Artefakte sind timestamped)
│       │   ├── altair_plot_1234567890.html
│       │   ├── altair_latest.html
│       │   ├── plotly_plot_1234567890.html
│       │   ├── plotly_latest.html
│       │   ├── df_dataframe_name.md
│       │   ├── df_dataframe_name.html
│       │   └── dataframes.json
│       ├── state.pkl
│       ├── exec_1234567890.py
│       └── user_code_1234567890.py
```

### 2.3 Code-Ausführung

#### 2.3.1 Endpoint

**Endpoint:** `POST /tools/python/execute`

**Request Schema:**
```python
{
    "user_id": str,                # User-ID (validiert)
    "session_uuid": str,           # Session-UUID (validiert)
    "code": str,                   # Python-Code (1-200.000 Zeichen)
    "timeout": int,                # Standard: 120s, Range: 1-120s
    "cwd": str                     # Arbeitsverzeichnis (optional)
}
```

#### 2.3.2 Ausführungsprozess

1. **Code-Bereinigung:**
   - Entfernt Markdown-Code-Fences (```python ... ```)
   - Entfernt optionalen Language-Tag

2. **Import-Validierung:**
   - Parst Code mit `ast.parse()`
   - Extrahiert alle Imports
   - Prüft gegen Whitelist (`ALLOWED_IMPORT_ROOTS`) und Blacklist (`DENY_IMPORT_ROOTS`)

3. **Wrapper-Generierung:**
   - Erstellt einen Wrapper-Script, der:
     - Matplotlib auf non-interactive Backend setzt (`MPLBACKEND=Agg`)
     - Python-State (Variablen) lädt/speichert via `cloudpickle`
     - Artifacts automatisch erkennt und speichert
     - DataFrames automatisch erkennt und Previews erstellt

4. **Ausführung:**
   - Führt Code in isoliertem Subprocess aus
   - Timeout: 1-120 Sekunden
   - Minimales Environment (nur PATH, HOME=/tmp)

5. **Artifact-Erkennung:**
   - **Matplotlib:** Speichert alle Figuren als PNG
   - **Altair:** Speichert Charts als HTML
   - **Plotly:** Speichert Figures als HTML
   - **Pandas DataFrames:** Erstellt Markdown- und HTML-Previews

6. **State-Persistenz:**
   - Speichert User-Variablen zwischen Ausführungen
   - Verwendet `cloudpickle` für Serialisierung
   - Überspringt nicht-serialisierbare Objekte

### 2.4 Import-Regeln

#### Erlaubte Imports (Whitelist)

**Data Science:**
- `numpy`, `pandas`, `matplotlib`, `mpl_toolkits`
- `scipy`, `seaborn`, `sklearn`, `statsmodels`
- `altair`, `vega_datasets`, `plotly`, `pyarrow`
- `openpyxl`, `tabulate`, `bs4`, `lxml`, `cloudpickle`

**Standard Library (Safe):**
- `math`, `statistics`, `json`, `re`
- `datetime`, `time`, `random`
- `itertools`, `collections`, `typing`
- `csv`, `io`

#### Verbotene Imports (Blacklist)

- `os` - Verhindert Dateisystem-Zugriff außerhalb des Workspace
- `sys` - Verhindert System-Manipulation
- `subprocess` - Verhindert Ausführung externer Programme
- `socket` - Verhindert Netzwerk-Zugriff
- `pathlib` - Verhindert direkten Pfad-Zugriff (Wrapper verwendet intern Pathlib)
- `shutil` - Verhindert Datei-Operationen
- `ctypes` - Verhindert Low-Level-Zugriff
- `multiprocessing` - Verhindert Parallel-Processing
- `asyncio` - Verhindert Async-Operationen
- `signal` - Verhindert Signal-Handling
- `resource` - Verhindert Resource-Limits-Manipulation

### 2.5 Artifact-Handling

#### Automatische Artifact-Erkennung

1. **Matplotlib Figures:**
   - Erkennt alle aktiven Figures via `plt.get_fignums()`
   - Speichert als `plot_{timestamp}.png`
   - DPI: 150, bbox_inches="tight"

2. **Altair Charts:**
   - Sucht nach Variablen mit Namen: `final_plot`, `chart`, `plot`, `altair_chart`, `vis`
   - Falls nicht gefunden, sucht nach allen Altair-Objekten im Namespace
   - Speichert als HTML (kein PNG-Export nötig)

3. **Plotly Figures:**
   - Sucht nach Variablen: `fig`, `figure`, `plotly_fig`
   - Falls nicht gefunden, sucht nach Plotly-Objekten im Namespace
   - Speichert als HTML mit CDN-Embedded Plotly.js

4. **Pandas DataFrames:**
   - Erkennt alle `pd.DataFrame` Objekte im Namespace
   - Erstellt Markdown-Preview (erste 25 Zeilen)
   - Erstellt HTML-Preview (erste 200 Zeilen)
   - Speichert Metadaten in `dataframes.json`

### 2.6 State-Persistenz

#### Funktionsweise

1. **State-Laden:**
   - Lädt `state.pkl` falls vorhanden
   - Merged gespeicherte Variablen in den Namespace
   - Überschreibt keine Base-Imports (np, pd, plt, etc.)

2. **State-Speichern:**
   - Speichert alle User-Variablen (außer Base-Imports)
   - Überspringt nicht-serialisierbare Objekte
   - Überspringt Module und Builtins

3. **Verwendung:**
   - Ermöglicht Variablen-Persistenz zwischen Code-Ausführungen
   - Nützlich für iterative Datenanalyse
   - State wird pro Session gespeichert

### 2.7 Sicherheitsmechanismen

1. **Code-Isolation:**
   - Ausführung in separatem Subprocess
   - Minimales Environment
   - Timeout-Begrenzung

2. **Import-Restriktionen:**
   - Whitelist für erlaubte Imports
   - Blacklist für gefährliche Imports
   - AST-basierte Validierung vor Ausführung

3. **Resource-Limits:**
   - Timeout: 1-120 Sekunden
   - Code-Länge: 1-200.000 Zeichen
   - Workspace-Isolation pro User/Session

4. **Path-Sicherheit:**
   - Alle Pfade relativ zum Session-Workspace
   - Path Traversal wird verhindert
   - `cwd` wird validiert

## 3. Integration mit Django

### 3.1 Agent-Execution-Flow

1. **User sendet Nachricht** → Django View (`generate_agent_response_stream`)

2. **Planner-Phase:**
   - LLM plant Tool-Calls basierend auf User-Request
   - Unterstützt Kaskadenketten (Cascade Chains) mit `depends_on`

3. **Tool-Execution-Phase:**
   - Iterative Ausführung (bis zu 10 Iterationen)
   - Nach jeder Iteration: Evaluation ob Ziel erreicht
   - Tool-Calls werden sequenziell ausgeführt

4. **Tool-Call-Typen:**
   - `web.search` → MCP Server (Port 9000)
   - `web.fetch` → MCP Server (Port 9000)
   - `web.download` → MCP Server (Port 9000)
   - `python.execute` → Python Sandbox (Port 9100)
   - `fs.list` → MCP Server (Port 9000)
   - `fs.read` → MCP Server (Port 9000)
   - `fs.write` → MCP Server (Port 9000)
   - `media.ytdlp.info` → MCP Server (Port 9000)

5. **Response-Streaming:**
   - Server-Sent Events (SSE) für Live-Updates
   - Tool-Call-Events für UI-Anzeige
   - MCP-Log-Events für detailliertes Logging
   - Artifact-URLs werden generiert

### 3.2 Tool-Result-Summarization

Um API-Payload-Größen zu begrenzen, werden Tool-Results vor der Evaluierung zusammengefasst:

- **web.fetch:** Nur Content-Preview (500 Zeichen), Länge, Status-Code
- **web.download:** Pfad, Größe, Status
- **python.execute:** Exit-Code, stdout/stderr-Previews, Artifact-Liste
- **fs.read:** Content-Preview (500 Zeichen), Länge
- **fs.write:** Pfad, Erfolg-Status

## 4. Docker-Container

### 4.1 MCP Server Container

**Image:** `python:3.11-slim`  
**Port:** 9000  
**Volume:** `/workspace` → `mcp_workspaces` (shared)

**Dependencies:**
- System: `curl` (für Health-Checks)
- Python: Siehe `mcp_server/requirements.txt`

### 4.2 Python Sandbox Container

**Image:** `python:3.11-slim`  
**Port:** 9100  
**Volume:** `/workspace` → `mcp_workspaces` (shared)

**Dependencies:**
- System:
  - `build-essential` (für Compilation)
  - `libcairo2`, `libpango-1.0-0`, `libpangocairo-1.0-0` (für Cairo/Pango)
  - `libgdk-pixbuf-2.0-0` (für Bildverarbeitung)
  - `libffi-dev` (für FFI)
  - `libfreetype6`, `libjpeg62-turbo`, `zlib1g` (für Matplotlib)
- Python: Siehe `python_sandbox/requirements.txt`

**Environment:**
- `MPLBACKEND=Agg` (non-interactive Matplotlib)

## 5. Sicherheits-Überlegungen

### 5.1 Sandbox-Isolation

- **User-Level:** Jeder User hat sein eigenes Verzeichnis
- **Session-Level:** Jeder Chat hat sein eigenes Arbeitsverzeichnis
- **Process-Level:** Python-Code läuft in isoliertem Subprocess
- **Network-Level:** Kein direkter Netzwerk-Zugriff aus Python-Code (nur über MCP Server)

### 5.2 Input-Validierung

- **Pydantic Models:** Alle Requests werden validiert
- **Regex-Validierung:** `user_id` (nur Zahlen), `session_uuid` (hex)
- **Path-Validierung:** Alle Pfade werden gegen Workspace-Root geprüft
- **Code-Validierung:** AST-Parsing für Import-Checks

### 5.3 Resource-Limits

- **Timeouts:** Alle Operationen haben Timeouts
- **Dateigrößen:** Limits für Downloads und Reads
- **Code-Länge:** Maximale Code-Größe (200KB)
- **Memory:** Durch Subprocess-Isolation begrenzt

### 5.4 Fehlerbehandlung

- **HTTP-Status-Codes:** Klare Fehlerbehandlung
- **Exception-Handling:** Try-Catch in kritischen Bereichen
- **Logging:** Detaillierte Logs für Debugging
- **Graceful Degradation:** Fallbacks wo möglich

## 6. Best Practices

### 6.1 Für Agent-Entwicklung

1. **Tool-Chaining:** Verwende `depends_on` für sequenzielle Operationen
2. **Artifact-Naming:** Verwende konsistente Namen für Plots (`final_plot`, `chart`, etc.)
3. **State-Management:** Nutze State-Persistenz für iterative Analysen
4. **Error-Handling:** Prüfe `exit_code` und `stderr` nach Python-Ausführungen

### 6.2 Für Code-Ausführung

1. **Matplotlib:** Kein `plt.show()` nötig, Figuren werden automatisch gespeichert
2. **Altair:** Charts werden automatisch erkannt und als HTML gespeichert
3. **DataFrames:** Werden automatisch erkannt und Previews erstellt
4. **Imports:** Nur erlaubte Libraries verwenden

### 6.3 Für Datei-Operationen

1. **Relative Pfade:** Immer relative Pfade zum Session-Workspace verwenden
2. **Overwrite:** `overwrite=True` für Datei-Updates
3. **Encoding:** Nur UTF-8 Text wird unterstützt
4. **Größen:** Beachte Limits (2MB für fs.read, 100MB für web.download)

## 7. Monitoring und Debugging

### 7.1 Health-Checks

- **MCP Server:** `GET /healthz` → `{"ok": true}`
- **Python Sandbox:** `GET /healthz` → `{"ok": true}`

### 7.2 Logging

- **MCP Server:** Uvicorn Access-Logs
- **Python Sandbox:** Uvicorn Access-Logs
- **Django:** Detailliertes MCP-Logging in `chat/views.py`

### 7.3 Fehler-Diagnose

1. **Tool-Call-Events:** Werden in UI angezeigt
2. **MCP-Log:** Detaillierte Logs im Chat-Interface
3. **Docker-Logs:** `docker compose logs mcp_server` / `python_sandbox`

## 8. Zukünftige Erweiterungen

### Mögliche Verbesserungen

1. **Weitere Tools:**
   - Datenbank-Connectors
   - API-Integrationen
   - Cloud-Storage (S3, etc.)

2. **Performance:**
   - Caching von Tool-Results
   - Parallele Tool-Ausführung
   - Code-Optimierung

3. **Sicherheit:**
   - Rate-Limiting
   - Quota-Management
   - Audit-Logging

4. **Features:**
   - Code-Versionierung
   - Collaborative Workspaces
   - Template-Library

---

**Version:** 1.0  
**Letzte Aktualisierung:** 2026-01-15  
**Autor:** Gangwai Development Team
