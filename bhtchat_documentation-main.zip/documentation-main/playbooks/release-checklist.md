# Release-Checklist

| Phase | Schritte |
| --- | --- |
| **Vorbereitung** | - Issue-Board leer? <br> - QA-Signoff dokumentiert <br> - Feature Flags dokumentiert |
| **Cut** | - `git tag vX.Y.Z` <br> - `buildx bake release` <br> - Artefakte signieren |
| **Veröffentlichung** | - ArgoCD Promote nach `prod` <br> - Synthetic Tests gegen `/healthz`, `/v1/chat` <br> - Statuspage aktualisieren |
| **Nachbereitung** | - Log Tail 30 Minuten <br> - Observability Checks (Errors < 0.1%) <br> - Retro-Issues anlegen |

## Entscheidungsbaum

```
[Cut Freeze?] --Nein--> [Stories abschließen] --loop--> [Cut Freeze?]
[Cut Freeze?] --Ja--> {Alle Checks grün?}
{Alle Checks grün?} --Nein--> [Fix + erneut testen]
{Alle Checks grün?} --Ja--> [Promote nach prod]
```

## Kommunikation

- Slack `#launch-control`: minütliche Updates
- Statuspage: „Maintenance“ während Deploy, „Monitoring“ danach
- Kundenmail bei Breaking Changes (Template in `/templates/release-mail.md`)

