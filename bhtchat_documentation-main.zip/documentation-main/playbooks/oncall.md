# On-Call Leitfaden

> **Ziel:** Innerhalb von 5 Minuten auf kritische Alarme reagieren und Kund:innen informieren.

## Rollen

- **Incident Commander (IC)** – steuert Kommunikation, hält Timeline aktuell.
- **Responder** – diagnostiziert und implementiert Fixes.
- **Comms Lead** – kümmert sich um Statuspage & Kundenkommunikation.

## Ablauf

1. **Alarmannahme** – PagerDuty bestätigt? → Slack `#incident` erstellen.
2. **Triagieren** – Severity bestimmen (S0 bis S3) anhand Kundenimpact.
3. **Stabilisierungsplan** – temporäre Maßnahmen (Rate-Limits, Feature Flags, Rollback).
4. **Kommunikation** – alle 15 Minuten Update.
5. **Abschluss** – Post-Incident-Review innerhalb von 48 Stunden.

## Runbooks

- **LLM API Degradation**
  - Flag `LLM_HARD_FAILOVER` setzen.
  - Traffic auf sekundären Provider verschieben (`/admin/runtime/providers`).
- **Redis Saturation**
  - `kubectl scale deployment worker --replicas=0` (Last rausnehmen).
  - `redis-cli monitor` + `slowlog get`.

## Checklisten

- [ ] Incident-ID im Tracker erstellt.
- [ ] Kunden-Comm gesendet (falls S0/S1).
- [ ] Follow-up Tasks mit Owner versehen.

