## Übersicht
____________________
### Chatübersicht

Der Pfeil nach links öffnet die Sidebar, die das Übersichtsmenü, zur Auswahl und Verwaltung aller geführten Chats, enthält.

![p 1](./p1.png)

Durch das erneute Klicken auf den Pfeil, lässt sich die Sidebar wieder verbergen.
>
>
_________________________________

### Neuen Caht starten

Durch das klicken auf "+ Neu" öffnet sich ein neuer Chat. Der vorherige Chat ist über die Chatauswahl weiterhin verfügbar.

![p 3](./p3.png)
>
______________________________

### LLM Auswahl

Auswahl der zur Verfügung stehenden LLMs (Chatanwendungen). Unteschiedliche LLMs sind für unterschiedliche Zwecke besonders gut geeigent wie z.B.: Coding, Recherche, Textanalyse, etc.

![p 4](./p4.png)
>
___________________________

### Einstellungen und Funktionen

Mit einem Klick auf das Zahnrad-Symbol, öffnet sich eine Übersicht mit Menüpunkten zu allgeimenen und speziefischen Einstellungen.  

![p 5](./p5.png)
>
_______________________________

### Dark/Light Mode umschalten

Durch das Klicken auf das Mond- bzw. Sonnen-Symbol lässt sich die Seite dunkel (wie hier gezeigt) oder dunkel darstellen. Siehe auch BArrierefreiheit

![p 6](./p6.png)
>
________________________________________

### Computer Vision

Das Augen-Symbol (Computer Vision) ermöglicht das Hochladen einer Bilddatei. Diese kann dann beschrieben, analysieren und interpretieren werden. 

![p 7](./p7.png)
>
________________________________

### Dokumente verarbeiten

Das Dokumenten-Symbol ermöglicht das Hochladen einer Textdatei (PDF, DOCX, TXT), welche beispielsweise zusammengefasst, ausgewertet oder, mit Anderen, verglichen werden kann.

![p 8](./p8.png)
>
__________________________________________________

### Nachrichtenfeld und Senden-Symbol

Hier werden die Nachrichten geschrrieben und durch das Drücken von Enter, oder das Klicken auf das Senden-Symbol, die Eingabe bestätigt.

![p 9](./p9.png)