## Einstellungen und Funktionen 
_________________________________________
Das Klicken auf das Zahnrad-Symbol öffnet das Dropdownmenü zu Einstellungen und Funktionen. 

![p 20](./p20.png)

### Info
-----

Unter dem Menüpunkt "Info" finden sich alle relevanten Service Informationen.

![p 21](./p21.png)

### Hilfe
---
Der Menüpunkt "Hilfe" führt zum "Gangway-Assistenten".
Hier finden sich kurze Zusammenfassungen und Erklärungen zu den wichtigsten Funktionen in einem scrollbaren Fenster.

![p 22](./p22.png)

### Schriftart und Größe
---

Der Menüpunkt "Schriftart & Größe" öffent das Übersichtsfenster für die Anpassung auf individuelle Bedürfnisse und Präferenzen. Siehe auch Barrierefreiheit.

![p 23](./p23.png)

"System" ist die als Standart festgelegte Schriftart und 16 Pixel die Standart Schriftgröße. 

Im "Vorschau"-Feld wird ein Beispielsatz für die gewählten Einstellungen angezeigt. 

Über das "-"-Symbol (links) und "+"-Symbol (rechts), lässt sich die Schriftgröße stufenweise (zwischen 12 & 24 Pixeln) anpassen.

![p 24](./p24.png)

Die Schriftart lässt sich über das Dropdown-Menü auswählen

![p 25](./p25.png)
![p 26](./p26.png)

"Speichern" ändert die gewählten Einstellungen für alle neuen und bereits geführten Chats.

### Einstellungen
---
Der Menüpunkt "Einstellungen" öffnet ein Fenster welches viele Möglichkeiten zur Anpassung des Chats ermöglicht

#### Temperature

Der Slider "Temperature" bezieht sich auf einen Parameter, der die Kreativität bzw. die Zufälligkeit der vom Modell generierten Texte bestimmt. Eine niedrigere Temperatur führt dazu, dass das Modell konservativer ist, was zu vorhersehbareren und weniger variantenreichen Ergebnissen führt. Eine höhere Temperatur ermöglicht vielfältigere und kreativere Antworten, allerdings mit einem höheren Risiko für weniger kohärente Texte.

![p 28](./p28.png)

#### Top P

 Ein niedriger Top P-Wert führt dazu, dass das Modell nur aus den Wörtern mit den höchsten Wahrscheinlichkeiten wählt, was die Vorhersagen vorhersehbarer und weniger variantenreich macht. Ein höherer Top P-Wert erweitert die Auswahl auf weniger wahrscheinliche Wörter, was zu kreativeren und unerwarteteren Texten führen kann. 

![p 29](./p29.png)

Beide Paramteter zielen darauf ab, eine Balance zwischen kohärentem und kreativem Text zu finden, unterscheiden sich jedoch in der technischen Umsetzung dieser Balancierung.

#### Max Tokens

"Max Tokens" legt fest, wie viele Token das Modell in einer Ausgabe erzeugen darf. Dies ist wichtig, um den Umfang der generierten Antwort zu begrenzen, was für die Steuerung der Ausgabelänge maßgeblich ist.


![p 30](./p30.png)

 Token sind die kleinsten Einheiten, in die ein Text zerlegt wird, und sie können Wörter, Satzzeichen oder sogar Teile von Wörtern sein, abhängig von der Tokenisierungsmethode.
 
 #### System Prompts 
 
 
 
 ![p 31](./p31.png)

#### Feedback
Das Textfeld unter "Feedback geben" ermöglicht es Hinweise zu geben, Vorschläge zu machen oder fehler zu melden.


![p 27](./p27.png)