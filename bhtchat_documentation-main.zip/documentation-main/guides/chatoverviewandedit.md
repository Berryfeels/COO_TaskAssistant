## Chatüberischt und -funktionen


### Chatübersicht 
___________________
In der Chatübersicht sind alle bisher geführten Chats mit Namen, Zeit seit der letzten Bearbeitung und Vermek zur letzten Eingabe aufgeführt. Zudem erscheint ein ein permanentes, in blau hervorgehobenes, Teilen-Symbol angezeigt, wenn der Chat freigegeben wurde. (Siehe auch "Chat freigeben")

![p 10](./p10.png)

Beim Klicken auf einen der Chats öffnet sich dieser. Bei einer großen Menge geführter Chats, mit langen Verläufen, kann dies eventuell einige Sekunden dauern.
___________________

### Chat-Optionen 

Beim Verwielen auf einem der Chatauswahlfelder erscheinen drei vertikale Punket (Chat-Optionen).
Klickt man darauf, lässt sich der Chat umbenennen oder löschen.

![p 11](./p11.png)

_____________________________________

### Chat freigeben

Das Teilen-Symbol erscheint ebenfalls beim Verbleiben auf dem gewählten Chat. Klickt man darauf öffent sich das Freigabefenster.

![p 12](./p12.png)

Klickt man nun auf "Chat freigeben" generiert man einen öffentlich zugänglichen Link.

![p 13](./p13.png)

Durch das Anwählen des Punkts "Schreiben erlauben" wird zusätzlich die Ineraktion, im Chat für all jene gewärt, die über diesen Link zugang bekommen.

![p 14](./p14.png)

Über den Button "Kopieren" lässt sich der generierte Link nun an beliebeig viele Kontakte senden.

![p 15](./p15.png)

Wird der Chat über den externen Link geöffent, ist der Chatname und Username der Person vermekt, welche ihn zur Verfügung stellt. Zudem wird nur bedingt Zugriff auf Einstellungen gewährt (Anzeigeoptionen). 

- warten auf finale Ansicht externer Link - BILD

Wurde ein Chat freigegeben ist in der Chatübersicht ein permanentes, blaues Teilen-Symbol zu erkennen.

![p 16](./p16.png)

Schließlich lässt sich der Link aktualisieren (um ihn beispielsweise für andere Akteure zur Verfügung zu stellen) und löschen. Nach dem Löschen des Links kann dieser nicht mehr aufgerufen werden und ist somit unnutzbar. Wurde ein Link geschlöscht, verschwindet auch das permanente Teilen-Symbol aus der Chatübersicht.

![p 17](./p17.png)
