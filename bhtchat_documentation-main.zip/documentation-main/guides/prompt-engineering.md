# Prompt Engineering


image.png


### **• Überprüfung, Reflexion und Qualitätssteigerung eigener Leistungen**

Generative KI kann als zusätzliches Feedback-Werkzeug dienen, um eigene Ergebnisse kritisch zu prüfen und weiterzuentwickeln. Dies umfasst das Analysieren von Programmcode, das Bewerten fachlicher Lösungswege oder das Überarbeiten eigener Texte. Die KI hilft, Fehler aufzudecken, Alternativen aufzuzeigen und die Qualität der Arbeit systematisch zu verbessern.

**Beispiel-Prompts:**

Prüfe diesen Code auf Fehler und erkläre, was verbessert werden kann:> 
>
> ```python
> def add(a,b):  
>     return a-b  
> ```



> Welche logischen Schwächen erkennst du in dieser Argumentation?
>
> Bitte überarbeite diesen Absatz sprachlich und strukturell.

---

### **• Kreative Unterstützung bei komplexen Aufgabenstellungen**

KI-Systeme können als interaktive Ideengeber fungieren, wenn neue Perspektiven, alternative Lösungswege oder kreative Impulse benötigt werden. Sie regen Diskussionen an, erweitern Denkprozesse und helfen dabei, Herausforderungen aus unterschiedlichen Blickwinkeln zu betrachten.

**Beispiel-Prompts:**

> Entwickle drei alternative Ansätze für diese Fragestellung: „Wie könnte ein nachhaltiges Campus-Transportsystem aussehen?“
>


> Formuliere Gegenargumente zu dieser Position.
>


> Hilf mir, aus dieser Idee ein kleines Kurzgeschichten-Konzept zu machen.

---

### **• Individuelle Strukturierung, Anpassung und Erweiterung von Lerninhalten**

Mithilfe generativer KI lassen sich Lernmaterialien den eigenen Bedürfnissen entsprechend zuschneiden: Inhalte können komprimiert, erweitert, verglichen, kategorisiert oder in Lernschritte überführt werden. Auf diese Weise lässt sich personalisiertes Lernen organisieren – von Übersichten bis zum maßgeschneiderten Lernplan.

**Beispiel-Prompts:**

> Fasse dieses Kapitel in fünf Kernaussagen zusammen.
>


> Erstelle mir einen Lernplan für zwei Wochen, basierend auf diesem Text.
>


> Erkläre mir diesen Inhalt so, als wäre ich Anfänger*in.
>


> Vergleiche die beiden Konzepte und mache eine übersichtliche Tabelle.


---

### **• Unterstützung beim Einstieg in Schreibprozesse sowie bei der sprachlichen Ausarbeitung**

Generative KI erleichtert den Einstieg ins Schreiben, indem sie Themenvorschläge liefert, Rohideen strukturiert oder sprachliche Präzision verbessert. Texte können umformuliert, übersetzt, erweitert oder stilistisch angepasst werden. Dadurch wird flüssigeres Schreiben ermöglicht.

**Beispiel-Prompts:**

> Übersetze diesen Absatz ins Englische und formuliere ihn anschließend formeller.
>


> Gib mir fünf mögliche Themen für eine Hausarbeit über „Künstliche Intelligenz und Bildung“.
>


> Schreibe aus diesen Stichpunkten einen klaren Absatz:
> – vernetzte Systeme
> – Protokolle
> – Konsistenzprobleme
>


> Formuliere diesen Satz abwechslungsreicher.

---

### 👉 Zusätzlich: Beispiele für andere häufige Nutzungsszenarien

#### **Mathematische Probleme lösen**

> Erkläre Schritt für Schritt, wie man diese Gleichung löst:
>
> ( 3x + 5 = 20 )
>


> Zeige mir drei Wege, wie man den Satz des Pythagoras anschaulich verstehen kann.

---

#### **SQL-Anweisungen erzeugen**

> Schreibe eine SQL-Query, die alle Studierenden ausgibt, die mehr als 30 Credits haben.
>


> Erstelle ein CREATE TABLE-Statement für eine Kursverwaltung mit Kursname, ID und Dozent.

---

#### **Lustige Alliterationen**

> Erfinde fünf Alliterationen über eine neugierige Krabbe.
>


> Schreibe eine alliterative Mini-Geschichte über Mathematiker*innen.
>


> Gib mir lustige Alliterationsvorschläge für das Wort „Roboter“.

---

Wenn du möchtest, kann ich diese Beispiele:

* in **verschiedene Schwierigkeitsstufen** einteilen,
* als **Poster / Infografik-Format** vorbereiten,
* oder **für ein Jupyter-Notebook** aufbereiten.
