# Notebook: Docling → E5 Embeddings

> **Ziel:** Interne Teams sollen die vollständige Dokument-zu-Embedding-Pipeline in einem Jupyter Notebook nachvollziehen und reproduzieren können.  
> **Reifegrad:** Beta (funktional, aber ohne ausgedehnte Fehlerbehandlung).  
> **Stand:** 02.12.2025

## Kontext & Referenz im Backend

- Die Django-View `process_document` (`chat/views.py`) ruft bereits den Docling-Endpunkt auf, um hochgeladene Dateien in Markdown zu überführen. Die Notebook-Schritte unten spiegeln exakt diese Logik wider, damit lokale Analysen ohne Backend-Änderungen möglich bleiben.

```python
# chat/views.py::process_document (gekürzt)
response = requests.post(
    'https://chat-ai.academiccloud.de/v1/documents/convert',
    files={'document': f},
    headers={'Authorization': f'Bearer {API_KEY}', 'accept': 'application/json'},
    timeout=120,
)
response.raise_for_status()
markdown_content = response.json().get('markdown', '')
```

- Nach der Konvertierung erzeugen wir Embeddings mit dem internen OpenAI-kompatiblen Endpoint `/v1/embeddings` und dem Modell `e5-mistral-7b-instruct` (alternativ `multilingual-e5-large-instruct`). E5 verlangt weiterhin die bekannten Präfixe `passage:` bzw. `query:`.
- Das Notebook arbeitet ausschließlich mit bestehenden APIs – der Anwendungs-Code bleibt unverändert.

## Voraussetzungen

1. **Dokumentbasis:** Die Datei `Gesund_durch_richtige_Ernaehrung.pdf` liegt im Repository-Root (`/home/fosh/gangwai`). Die Notebook-Zelle prüft den Pfad und bricht andernfalls mit einer aussagekräftigen Fehlermeldung ab.
2. **Python-Umgebung:** `python >= 3.10`, installierbare Pakete `requests`, `python-dotenv`, `pandas`, `numpy`, `tqdm`.

   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install requests python-dotenv pandas numpy tqdm
   ```

3. **API-Key sicher hinterlegen:** Für Jupyter-Book-Workflows bewährt sich eine `.env`-Datei (bereits durch `.gitignore` ausgeschlossen).

   ```bash
   cat <<'EOF' > .env
   ACADEMIC_API_KEY="***-hier-den-schlüssel-einfügen***"
   EOF
   ```

   Die Notebook-Zellen nutzen `python-dotenv`, sodass der Key nie im Klartext im Notebook auftaucht.

## Notebook-Blueprint (Zelle für Zelle)

### 1. Imports & Pfade setzen

```python
from __future__ import annotations

import json
import os
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT = Path("/home/fosh/gangwai").resolve()
DOC_PATH = ROOT / "Gesund_durch_richtige_Ernaehrung.pdf"
assert DOC_PATH.exists(), f"Dokument nicht gefunden: {DOC_PATH}"

load_dotenv()
API_KEY = os.getenv("ACADEMIC_API_KEY")
if not API_KEY:
    raise RuntimeError("ACADEMIC_API_KEY fehlt – siehe .env")

BASE_URL = "https://chat-ai.academiccloud.de/v1"
EMBEDDING_MODEL = "e5-mistral-7b-instruct"
```

### 2. Docling-Konvertierung (PDF → Markdown-String)

```python
def convert_with_docling(pdf_path: Path) -> str:
    with pdf_path.open("rb") as binary:
        response = requests.post(
            f"{BASE_URL}/documents/convert",
            files={"document": (pdf_path.name, binary, "application/pdf")},
            headers={"Authorization": f"Bearer {API_KEY}", "accept": "application/json"},
            timeout=120,
        )

    response.raise_for_status()
    markdown = response.json().get("markdown", "")
    if not markdown:
        raise ValueError("Docling lieferte keinen Markdown-Inhalt.")
    return markdown

markdown_text = convert_with_docling(DOC_PATH)
print(f"Markdown-Länge: {len(markdown_text):,} Zeichen")
print(markdown_text[:500])
```

### 3. Normalisieren & Chunking

```python
def chunk_markdown(text: str, chunk_chars: int = 1_200, overlap: int = 200):
    sanitized = "\n".join(line.strip() for line in text.splitlines() if line.strip())
    chunks = []
    start = 0

    while start < len(sanitized):
        end = min(len(sanitized), start + chunk_chars)
        chunk_text = sanitized[start:end]
        chunks.append(
            {
                "text": chunk_text,
                "start": start,
                "end": end,
            }
        )
        start = end - overlap

    return chunks

chunks = chunk_markdown(markdown_text)
print(f"{len(chunks)} Chunks generiert; erster Chunk:\n{chunks[0]['text'][:400]}")
```

### 4. Anfrage an E5 Instruct /v1/embeddings

```python
def embed_passages(passages: list[dict], model: str = EMBEDDING_MODEL):
    payload = {
        "model": model,
        "input": [f"passage: {chunk['text']}" for chunk in passages],
        "encoding_format": "float",
    }
    response = requests.post(
        f"{BASE_URL}/embeddings",
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        json=payload,
        timeout=60,
    )
    response.raise_for_status()
    data = response.json()["data"]

    for chunk, embedding in zip(passages, data, strict=True):
        chunk["embedding"] = embedding["embedding"]
        chunk["embedding_index"] = embedding.get("index")

    return passages, len(data[0]["embedding"])

chunks, embedding_dim = embed_passages(chunks)
print(f"Dimensionalität: {embedding_dim} – Beispielwert {chunks[0]['embedding'][:5]}")
```

### 5. Persistieren & Plausibilisieren

```python
import pandas as pd

df = pd.DataFrame(
    {
        "chunk_id": range(len(chunks)),
        "start": [c["start"] for c in chunks],
        "end": [c["end"] for c in chunks],
        "text": [c["text"] for c in chunks],
        "embedding": [json.dumps(c["embedding"]) for c in chunks],
    }
)

output_path = ROOT / "Gesund_durch_richtige_Ernaehrung.embeddings.parquet"
df.to_parquet(output_path, index=False)
df.head()
```

### 6. Queries vergleichen (optional)

```python
import numpy as np
from numpy.linalg import norm

def embed_query(query: str, model: str = EMBEDDING_MODEL) -> list[float]:
    payload = {"model": model, "input": [f"query: {query}"], "encoding_format": "float"}
    response = requests.post(
        f"{BASE_URL}/embeddings",
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
        json=payload,
        timeout=30,
    )
    response.raise_for_status()
    return response.json()["data"][0]["embedding"]

def cosine(a, b):
    a_vec, b_vec = np.array(a), np.array(b)
    return float(a_vec @ b_vec / (norm(a_vec) * norm(b_vec)))

query_embedding = embed_query("Welche Empfehlungen gibt es für ballaststoffreiche Ernährung?")
scored = [
    (cosine(query_embedding, chunk["embedding"]), chunk["text"][:180])
    for chunk in chunks
]

top_hits = sorted(scored, reverse=True)[:3]
for score, preview in top_hits:
    print(f"{score:.3f} → {preview}…\n")
```

## Fehlerbilder & Debugging

- **401 Unauthorized:** `.env` nicht geladen oder Token abgelaufen. Notebook-Zelle 1 erneut ausführen und Key bei `my.academiccloud.de` prüfen.
- **Timeout bei Docling:** Große PDFs > 50 MB führen zu langen Laufzeiten. Vorab kostenlos komprimieren oder im Backend-Modal Stück für Stück hochladen.
- **Leere Embeddings:** E5 braucht das Präfix `passage:`/`query:`. Ohne Präfix liefert das Modell konstante Vektoren.
- **Dimensionalität weicht ab:** Prüfen, ob versehentlich `qwen3-embedding-4b` ausgewählt wurde – die Dimension springt dann auf 1536.

## Weiterführende Schritte

- Embeddings in Redis oder Postgres (`jsonb`) ablegen, um im Chat-Backend schnelle Lookup-Tabellen zu haben.
- Chunking mit `nltk` oder `tokenizers` verfeinern, sobald der gewünschte Kontextumfang pro Antwort klar ist.
- RAG-Prototypen direkt im Notebook evaluieren, indem die Treffer in `ChatSession`-Nachrichten injiziert werden (keine Codeänderung erforderlich).

