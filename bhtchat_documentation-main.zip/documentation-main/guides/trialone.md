## Übersicht
____________________

Der Pfeil nach links öffnet eine Sidebar, die das Übersichtsmenü, zur Verwaltung aller geführten Chats, öffnet.

![p 1](./p1.png)

Durch das erneute Klicken auf den Pfeil, der jetzt nach rechts zeigt, lässt sich die Sidebar wieder verbergen.

![p 2](./p2.png)


