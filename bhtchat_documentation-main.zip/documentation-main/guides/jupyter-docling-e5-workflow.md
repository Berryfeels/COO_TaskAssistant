# Jupyter-Workflow: Docling → E5 Mistral Instruct

Ziel: Den in der App verwendeten Dokumentenpfad (Upload → Docling → Markdown → Embeddings) 1:1 in einem Notebook reproduzieren und wissenschaftlich untersuchen. Alle Schritte bleiben API-kompatibel – der Django-Code muss nicht angepasst werden.

## Wo das im Backend passiert
- `chat/views.py::process_document` ruft Docling auf, um hochgeladene Dateien in Markdown zu konvertieren.
- `DocumentUpload.embedding_model` hält das gewünschte Embedding-Modell (`e5-mistral-7b-instruct` als Standard).
- `chat/views.py::generate_document_response_stream` kombiniert Nutzerprompt + gespeichertes Markdown und ruft anschließend das LLM (nicht das Embedding-Modell) für die finale Antwort auf.

## Voraussetzungen
1) Python ≥ 3.10, Pakete: `requests`, `python-dotenv`, `pandas`, `numpy`, `tqdm`.  
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install requests python-dotenv pandas numpy tqdm
   ```
2) API-Key in `.env` (liegt auf Ignore-Liste):  
   ```bash
   cat <<'EOF' > .env
   ACADEMIC_API_KEY="*** hier Key eintragen ***"
   EOF
   ```
3) Beispiel-PDF im Repo-Root: `/home/fosh/gangwai/Gesund_durch_richtige_Ernaehrung.pdf` (oder eigenen Pfad setzen).

## Notebook-Schritte (kopierbar pro Zelle)

### 1. Imports, Pfade, Konstanten
```python
from __future__ import annotations
import json, os
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT = Path("/home/fosh/gangwai").resolve()
DOC_PATH = ROOT / "Gesund_durch_richtige_Ernaehrung.pdf"
assert DOC_PATH.exists(), f"Dokument fehlt: {DOC_PATH}"

load_dotenv()
API_KEY = os.getenv("ACADEMIC_API_KEY")
if not API_KEY:
    raise RuntimeError("ACADEMIC_API_KEY fehlt – siehe .env")

BASE_URL = "https://chat-ai.academiccloud.de/v1"
EMBEDDING_MODEL = "e5-mistral-7b-instruct"
CHAT_MODEL = "llama-8b"  # entspricht dem Default im Backend
```

### 2. Docling: PDF → Markdown
```python
def convert_with_docling(pdf_path: Path) -> str:
    with pdf_path.open("rb") as binary:
        resp = requests.post(
            f"{BASE_URL}/documents/convert",
            files={"document": (pdf_path.name, binary, "application/pdf")},
            headers={"Authorization": f"Bearer {API_KEY}", "accept": "application/json"},
            timeout=120,
        )
    resp.raise_for_status()
    markdown = resp.json().get("markdown", "")
    if not markdown:
        raise ValueError("Docling lieferte keinen Markdown-Text.")
    return markdown

markdown_text = convert_with_docling(DOC_PATH)
print(f"Markdown-Länge: {len(markdown_text):,} Zeichen")
print(markdown_text[:500])
```

### 3. Normalisieren & Chunking
```python
def chunk_markdown(text: str, chunk_chars: int = 1_200, overlap: int = 200):
    # einfache Zeichen-basierte Chunks (wie in der App gespeichert)
    sanitized = "\n".join(line.strip() for line in text.splitlines() if line.strip())
    chunks, start = [], 0
    while start < len(sanitized):
        end = min(len(sanitized), start + chunk_chars)
        chunks.append({"text": sanitized[start:end], "start": start, "end": end})
        start = end - overlap
    return chunks

chunks = chunk_markdown(markdown_text)
print(f"{len(chunks)} Chunks; erster Chunk:\n{chunks[0]['text'][:400]}")
```

### 4. Embeddings mit E5 Mistral Instruct
E5 erwartet Präfixe: `passage:` für Dokumente, `query:` für Fragen.
```python
def embed_passages(passages: list[dict], model: str = EMBEDDING_MODEL):
    payload = {
        "model": model,
        "input": [f"passage: {c['text']}" for c in passages],
        "encoding_format": "float",
    }
    resp = requests.post(
        f"{BASE_URL}/embeddings",
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        json=payload,
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()["data"]
    for chunk, emb in zip(passages, data, strict=True):
        chunk["embedding"] = emb["embedding"]
    return passages, len(data[0]["embedding"])

chunks, embedding_dim = embed_passages(chunks)
print(f"Dimensionalität: {embedding_dim} – Beispiel: {chunks[0]['embedding'][:5]}")
```

### 5. Query-Embedding + Ranking
```python
import numpy as np
from numpy.linalg import norm

def embed_query(query: str, model: str = EMBEDDING_MODEL) -> list[float]:
    resp = requests.post(
        f"{BASE_URL}/embeddings",
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
        json={"model": model, "input": [f"query: {query}"], "encoding_format": "float"},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["data"][0]["embedding"]

def cosine(a, b):
    a_vec, b_vec = np.array(a), np.array(b)
    return float(a_vec @ b_vec / (norm(a_vec) * norm(b_vec)))

query = "Welche Empfehlungen gibt es für ballaststoffreiche Ernährung?"
q_emb = embed_query(query)
scored = [(cosine(q_emb, c["embedding"]), c["text"][:180]) for c in chunks]
top_hits = sorted(scored, reverse=True)[:3]
for score, preview in top_hits:
    print(f"{score:.3f} → {preview}…\n")
```

### 6. (Optional) Antwort generieren wie im Backend
Die App steckt Markdown direkt in den Prompt. Im Notebook können wir die bestplatzierten Chunks injizieren und das LLM ansprechen.
```python
context = "\n\n".join(text for _, text in top_hits)
messages = [
    {"role": "system", "content": "Du bist ein Assistent, der nur aus den Dokumenten antwortet."},
    {"role": "user", "content": f"Frage: {query}\n\nDokumentauszüge:\n{context}\n\nAntworte knapp und belege mit Zitaten."},
]

resp = requests.post(
    f"{BASE_URL}/chat/completions",
    headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
    json={"model": CHAT_MODEL, "messages": messages, "temperature": 0.2, "top_p": 0.9, "max_tokens": 600},
    timeout=60,
)
resp.raise_for_status()
print(resp.json()["choices"][0]["message"]["content"])
```

### 7. Persistieren (Parquet) für Analysen
```python
import pandas as pd

df = pd.DataFrame(
    {
        "chunk_id": range(len(chunks)),
        "start": [c["start"] for c in chunks],
        "end": [c["end"] for c in chunks],
        "text": [c["text"] for c in chunks],
        "embedding": [json.dumps(c["embedding"]) for c in chunks],
    }
)
out_path = ROOT / "Gesund_durch_richtige_Ernaehrung.embeddings.parquet"
df.to_parquet(out_path, index=False)
df.head()
```

## Fehlerbilder & Checks
- 401: Key fehlt oder abgelaufen → `.env` neu laden.
- Timeout bei Docling: PDFs > 50 MB ggf. vorab verkleinern.
- Flache Scores: Präfixe `passage:`/`query:` vergessen?
- Falsche Dimension: Kontrollieren, ob ein anderes Embedding-Modell gewählt wurde.

## Mapping Notebook ↔ App
- Notebook-Schritt 2 spiegelt `process_document` (Docling-Aufruf).
- Notebook-Schritt 4 nutzt dasselbe Embedding-Modell, das im Frontend als Default vorbelegt ist (`document_modal.html`).
- Notebook-Schritt 6 entspricht dem Prompt-Bau in `generate_document_response_stream`, nur dass hier die Top-Chunks explizit ausgewählt werden.


