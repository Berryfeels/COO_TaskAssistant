# Guides

Die Guides bündeln praxisnahe Schritt-für-Schritt-Anleitungen. Jede Seite beantwortet drei Fragen:

1. **Warum?** – Kontext, Ziele und erwartete Ergebnisse.
2. **Wie?** – Klare Schritte, idealerweise mit Code- oder Konfigurationsbeispielen.
3. **Was dann?** – Hinweise für Anschlussaufgaben oder Qualitätschecks.

> **Tipp:** Halte Kapitel kurz (< 5 Minuten Lesezeit) und verlinke tiefergehende Hintergründe aus der Architektursektion. So bleibt das Git-Book leicht navigierbar.

