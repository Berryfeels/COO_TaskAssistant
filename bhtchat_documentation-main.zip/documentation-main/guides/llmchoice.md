## LLM Auswahl

![p 19](./p19.png)

# Platzhalter Dropdown Darkmode bereinigt
