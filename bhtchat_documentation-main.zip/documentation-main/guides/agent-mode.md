# Agenten-Modus (Tool-gestützte Ausführung)

Diese Seite dokumentiert, wie der **Agenten-Modus** in Gangwai aktuell funktioniert: vom UI-Toggle über SSE-Streaming bis zur Tool-Ausführung, Artefakt-Auslieferung und Worktree-Anzeige.

## Überblick (Was ist „Agent“ hier?)

Im Agenten-Modus kann eine Assistenz-Antwort **nicht nur Text streamen**, sondern auch:

- **Tool-Calls planen** (Planner)
- **Tools sequentiell ausführen** (Executor)
- **Zwischenergebnisse evaluieren** und bei Bedarf **weitere Tool-Schritte** anstoßen (Iterationen)
- **Artefakte** (z.B. Plot-Bilder, HTML-Charts, CSV/MD) als **Worktree-Dateien** erzeugen und im Chat verlinken/rendern

Technisch ist das ein SSE-Stream („Server-Sent Events“) mit zusätzlichen Event-Typen für Tool-Status + Live-Logs.

## Aktivierung / Settings

- **UI**: Agent wird über das Agent-Modal aktiviert (persistiert pro Chat-Session).
- **Server-Speicherung**: Agent-Settings werden in `ChatSession.metadata["agent"]` gespeichert.
- **Endpoint**: `GET/POST /chat/agent/preference/?session_uuid=...` liefert/ändert:
  - `agent_enabled: bool`
  - `tools: { <tool_key>: bool }` (Allowlist pro Tool-Code)

## Request-Flow: Nachricht → Stream

1. **User sendet Prompt** → Backend erstellt eine `ChatMessage(role="user")`.
2. Backend entscheidet anhand `agent_enabled`:
   - **Normal**: `chat:chat-response-stream`
   - **Agent**: `chat:agent-response-stream`
3. Frontend rendert eine Streaming-Bubble und startet SSE.

## SSE-Streaming: welche Events?

Der Stream liefert JSON-Datenframes, die im Frontend inkrementell verarbeitet werden:

- **`content`**: Text-/Markdown-Tokenstream für die Assistant-Bubble.
- **Tool-Events**: Status/Result-Objekte („running/completed/failed“) für die Tool-Panel-Karten.
- **MCP Live Log**: Terminal-artige Log-Lines (für Debugging/Transparenz).

## Agent-Pipeline (Planner → Executor → Evaluation)

Der Agenten-Stream besteht konzeptionell aus drei Schritten:

### 1) Planner (Tool-Auswahl)

- Der Planner bekommt den User-Prompt + History + Tool-Allowlist.
- Ergebnis: Liste geplanter Tool-Calls (inkl. Argumente).
- Zusätzlich existieren „Deterministic Chains“ (z.B. Plot-Autokette), die bestimmte Tool-Calls erzwingen können, wenn der Planner sie nicht setzt.

### 2) Executor (Tool-Ausführung)

- Tool-Calls werden **sequenziell** ausgeführt.
- Es gibt ein **Iterationen-Limit** (Schutz gegen Endlos-Loops).
- Tool-Results werden vor der nächsten Iteration **zusammengefasst**, um Payloads klein zu halten (insb. `web.fetch` etc.).

### 3) Evaluation (Re-Evaluation / mehrfache API-Abfragen)

Nach jedem Schritt/Iteration kann der Agent:

- prüfen, ob das Ziel erreicht ist
- die Tool-Planung mit neuer Sachlage **neu anwerfen**
- weitere Schritte einplanen

Das ist der Kern der gewünschten „autonomen Handlung“: **nicht nur initial planen**, sondern **zwischen-drin neu bewerten**.

## Tools (aktuell) – Codes & Zweck

Aktuell sind Tool-Codes in der UI auswählbar und werden serverseitig als Allowlist enforced:

- **`web.search`**: Suche (DDGS)
- **`web.fetch`**: URL abrufen (Text/HTML/JSON)
- **`web.download`**: Binärdownload in den Worktree (PDF, XLSX, Images, …)
- **`web.extract.media`**: Medien-Links aus HTML extrahieren
- **`python.execute`**: Sandbox-Python ausführen (Artefakte werden automatisch erkannt)
- **`fs.list` / `fs.read` / `fs.write`**: Worktree-IO über MCP
- **`doc.convert`**: Docling-basierte Konvertierung (mit Fallbacks)
- **KB-Tools**: `kb.space.ensure`, `kb.space.stats`, `kb.ingest.web`, `kb.ingest.pdf`, `kb.embed.upsert`, `kb.retrieve`
- **`vision.analyze`**: Bildanalyse (Vision)
- **`media.ytdlp.info`**: Video-Metadaten
- **`session.history.get`**: Lokales Tool für kompakte History (nützlich für Planning/Evaluation)

## Artefakte: Erzeugung, Links, Rendering

### Erzeugung

- `python.execute` kann z.B. Plots als PNG speichern und deren Pfade als „artifact marker“ in stdout ausgeben.
- MCP-Tools (z.B. `web.download`) schreiben Dateien direkt in den Worktree.

### Auslieferung

- Artefakte werden über Django ausgeliefert:
  - privat: `/chat/agent/artifact/<session_uuid>/<relpath>/`
  - shared: `/chat/shared/<share_uuid>/artifact/<relpath>/`

### Rendering

- Tool-Panels rendern `artifact_urls` je nach Typ (PNG direkt als `<img>`, HTML als „Open in new tab“, MD mit optionalem Inline-Preview).
- Zusätzlich können Plot-Artefakte am Ende in die Assistant-Antwort eingebettet werden.

## Worktree-Anzeige

- Endpoint: `GET /chat/agent/worktree/<session_uuid>/` listet alle Dateien (Name, Pfad, Größe, mtime).
- UI: ein dezenter Dropdown in der Message-Bubble zeigt die Worktree-Dateien und verlinkt direkt auf Artefakte.

**Zielbild**: Wenn Agent aktiv ist, soll der Worktree **immer sichtbar** sein (auch wenn noch leer) und sich nach Tool-Läufen zuverlässig aktualisieren.

## Bekannte Stolperstellen / Debugging

- **Encodierte Slashes in Pfaden**: URLs sollten Pfadsegmente einzeln encoden, aber `/` beibehalten.
- **Dateityp-Erkennung**: URLs mit Trailing-Slash brauchen robuste Extension-Erkennung (z.B. `.png/` → `.png`).
- **Streaming-Bilder / Platzhalter**: Während SSE-Streaming werden Remote-Bilder bewusst unterdrückt (Browser-Aborts/Spam). Nach Abschluss muss **ein finaler Re-Render** mit `isStreaming=false` passieren, damit lokale Artefakte (Plots) wirklich als `<img>` erscheinen.
- **Worktree initialisiert nicht zuverlässig**: `setTimeout(loadFiles)` muss im Alpine-Scope ausgeführt werden (z.B. `setTimeout(() => $data.loadFiles(), 500)`), sonst wird der Worktree manchmal nie geladen.
- **PDFs**:
  - **Auslieferung**: korrektes `Content-Type: application/pdf` + sinnvolle `Content-Disposition` verbessern „Open in Browser“ deutlich.
  - **Download-Quelle**: `web.download` kann “erfolgreich” sein, obwohl der Server HTML (Login/Error) liefert. Daher lohnt sich PDF-Validierung (Magic Bytes `%PDF-`) und ein klares Tool-Error statt einer kaputten Datei im Worktree.

## Empfehlungen: Tool-Codes für den Ausbau

Für „divers“ und „harmonierend“ würde ich Tool-Codes in Schichten ergänzen:

### A) Repo/Worktree „Developer Tools“

- **`git.status`**: geänderte Dateien, untracked, summary (statt Full-Tree Walk)
- **`git.diff`**: Diff für Pfad/Range (Patch-Preview, hilft bei Agent-Evaluation)
- **`fs.search`**: ripgrep-artige Suche im Worktree (statt `fs.read`+LLM Heuristik)
- **`fs.delete` / `fs.move`**: Cleanup/Refactor ohne `fs.write`-Overload

### B) File/Doc Tools (robust gegen PDFs)

- **`file.info`**: MIME sniffing + Magic Bytes + Größe (vor dem Öffnen)
- **`pdf.extract_text`**: schnelle Text-Extraktion (Fallback, wenn Docling hängt)
- **`pdf.render_pages`**: PDF → PNG-Seiten (für Vorschau/QA)
- **`archive.extract`**: ZIP/TAR entpacken (Downloads sind oft gepackt)

### C) Observability / Agent-Control

- **`agent.plan`** (dry-run): Planner ohne Execution, damit User kontrollieren kann
- **`agent.evaluate`**: explizite Evaluations-Checks (Goal reached? next step?)
- **`trace.emit`**: strukturierte Trace-Events (Tool-Latenz, Errors, Retry-Gründe)

### D) Sicherheit/Policies

- **`policy.check`**: vor Tool-Execution prüfen (Domains allowlist, max-bytes, etc.)
- **`secrets.scan`**: verhindert Leaks beim Schreiben/Loggen

## Nächste Schritte (Roadmap)

- **Dokumentation pflegen** (diese Seite + Verweise in Architektur-Doku)
- **Worktree-Update-Mechanik** weiter verbessern (Event-getrieben, ggf. Polling während Agent läuft)
- **Tool-Registry** klar definieren (Schema, Args, Limits, Retry-Strategie)
- **Mehrstufige Re-Evaluation** formalisieren (Stop-Kriterien, Budget/Token-Limits, Tool-Timeouts)


