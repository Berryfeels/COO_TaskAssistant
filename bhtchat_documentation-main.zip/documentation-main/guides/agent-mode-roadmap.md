# Roadmap: Agenten-Modus (Stabilität → Autonomie → Tool-Ökosystem)

Diese Roadmap ist **für unser internes Verständnis**: was heute schon da ist, welche Probleme wir gesehen haben, und wie wir den Agenten-Modus strukturiert ausbauen (ohne „Tool-Wildwuchs“).

## Stand heute (Ist-Zustand)

- **UI Toggle + Tool-Allowlist**: pro `ChatSession` (persistiert in `metadata["agent"]`).
- **SSE Streaming**: Text (`content`) + Tool-Events + MCP-Live-Logs.
- **Planner → Executor → Evaluation**:
  - initiale Tool-Auswahl (Planner)
  - sequentielle Tool-Ausführung (Executor)
  - iterative Re-Evaluation („mehrfache Abfragen“) bis Ziel erreicht / Limit (Evaluation)
- **Artefakte & Worktree**:
  - Tools schreiben Dateien in den Worktree (z.B. `web.download`, `python.execute`, `fs.write`)
  - Django liefert Artefakte über stabile URLs aus
  - UI zeigt Tool-Panel (mit Artefakt-Rendering) + Worktree-Dropdown

## Aktuelle Pain Points (aus der Praxis)

- **PDF „download ok, aber nicht öffnbar“**: Quelle liefert evtl. HTML/Fehlerseite, Datei ist dann kein echtes PDF.
- **Python-Plots als Artefakte nur Platzhalter**: Streaming-Renderer unterdrückt Bilder; ohne finalen Re-Render bleiben Platzhalter stehen.
- **Worktree wird nicht immer geladen/aktualisiert**: Scope-Probleme bei `setTimeout`, plus Timing nach Tool-Läufen.

## Zielbild (Soll-Zustand)

- **Robust**: Artefakte (PNG/PDF/HTML/MD/CSV) rendern zuverlässig; Worktree ist in Agent-Mode immer sichtbar und „fresh“.
- **Autonom, aber kontrolliert**:
  - der Agent darf mehrfach planen/evaluieren
  - aber mit klaren Stop-Kriterien, Budgets und nachvollziehbarer Tool-Historie
- **Tool-Ökosystem harmonisch**:
  - einheitliches Schema (Args, Limits, Return-Form)
  - konsistente Error-Semantik (recoverable vs fatal)
  - observability (warum hat der Agent was getan?)

## Ausbau in Phasen

### Phase 0 – Stabilität & UX-Vertrauen (Pflicht)

- **Artefakt-Rendering**: Final-Render nach Stream-Ende (keine Platzhalter).
- **Worktree**:
  - Auto-Load stabil (Scope-fix)
  - Refresh nach file-touching Tools (event-getrieben)
- **Downloads**:
  - PDF-validieren (Magic Bytes) und bei Mismatch klar fehlschlagen (statt kaputte Datei)

### Phase 1 – „Mehrfache Abfragen“ formal machen (Autonomie-Loop)

- **Evaluation-Protokoll**:
  - „Goal reached?“
  - „What changed?“ (neue Fakten aus Tool-Results)
  - „Next best action?“
- **Stop-Kriterien**:
  - max Iterationen
  - max Tool-Calls
  - max Zeit
  - max Token
- **Retry-Strategie**:
  - nur bei recoverable errors
  - mit Backoff und klaren Gründen (im MCP log sichtbar)

### Phase 2 – Tool-Codes ergänzen (ohne Chaos)

Prinzip: Erst **Developer/Worktree** (damit der Agent zuverlässig mit Dateien umgehen kann), dann **Doc/PDF**, dann **Observability/Control**.

- **Developer/Worktree**
  - `fs.search` (rg-artig)
  - `fs.move`, `fs.delete`
  - `git.status`, `git.diff`
- **Doc/PDF**
  - `file.info` (MIME sniff + size)
  - `pdf.extract_text` (fast path)
  - `pdf.render_pages` (Preview/QA)
- **Observability/Control**
  - `agent.plan` (dry-run)
  - `agent.evaluate` (explizit, testbar)
  - `trace.emit` (strukturierte Events)

### Phase 3 – Tests & Regression Safety

- **Golden flows**:
  - Plot request → `python.execute` → PNG → wird im Chat sichtbar
  - PDF download → valid PDF → wird im Browser geöffnet
  - PDF download → HTML/403 → Tool fail + klare Meldung
- **UI Tests**: Worktree always-visible in Agent-Mode, refresh nach Tool-Ende.

## Implementations-Notizen (für die Doku-Änderungen)

- Wenn wir neue Tools hinzufügen: **ein Schema**, ein **Return-Contract**, und eine **Allowlist** (UI + server enforcement) sind Pflicht.


