# Schreibstil & Tonalität

Ein konsistenter Stil erhöht die Glaubwürdigkeit der Dokumentation. Nutze folgende Leitplanken:

## Stimme

- **Aktiv & direkt** – „Starte den Worker“, nicht „Der Worker sollte gestartet werden“.
- **Empathisch** – Leser:innen kommen oft mit Zeitdruck. Führe sie mit klaren Erwartungen („Dauer: 5 Minuten“).
- **Mehrsprachige Awareness** – Begriffe wie *Worker*, *Runbook* oder *Failover* nicht übersetzen, sondern kurz erklären.

## Struktur pro Seite

1. **Meta-Block** mit Ziel, Reifegrad und Aktualitätsdatum.
2. **Checkliste** oder nummerierte Schritte.
3. **Referenzen** – Links zu Code, Dashboards oder externen Spezifikationen.

## Formatierung

- Nutze Callouts (Blockquotes) für Warnungen und Tipps.
- Tabellen eignen sich für Vergleichsmatrizen (z. B. Feature Flags, SLAs).
- Codeblöcke immer mit Sprache annotieren und nach Möglichkeit ausführbar halten.

## Do & Don't

| Do | Don't |
| --- | --- |
| „Führe `python manage.py collectstatic` aus.“ | „Man kann collectstatic laufen lassen.“ |
| „Incident Commander aktualisiert den Status alle 15 Minuten.“ | „Jemand sollte ein Update posten.“ |

## Qualitätssicherung

- Las einen Buddy-Check durchführen, bevor du produktionskritische Kapitel veröffentlichst.
- Markiere größere inhaltliche Lücken mit `TODO:` statt sie zu verschweigen.
- Ergänze Screenshots nur, wenn sie essentielle UI-Schritte zeigen – ansonsten lieber textlich beschreiben.

