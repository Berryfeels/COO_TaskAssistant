## Einen neuen Chat starten

Klickt man auf "+ Neu" öffnet sich ein neuer Chat. 


![p 18](./p18.png)